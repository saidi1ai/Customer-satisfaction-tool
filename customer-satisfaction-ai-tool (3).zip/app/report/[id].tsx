import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, ScrollView, Share, Platform, Alert } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Copy, Share2, User, Calendar, FileText, AlertCircle } from 'lucide-react-native';

import Colors from '@/constants/colors';
import Card from '@/components/Card';
import Button from '@/components/Button';
import { reportsApi } from '@/services/apiService';

export default function ReportDetailScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const [copySuccess, setCopySuccess] = useState(false);
  const [report, setReport] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    const fetchReport = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const data = await reportsApi.getReport(id as string);
        setReport(data);
      } catch (err) {
        console.error('Error fetching report:', err);
        setError(err instanceof Error ? err.message : 'Failed to load report');
      } finally {
        setLoading(false);
      }
    };
    
    fetchReport();
  }, [id]);
  
  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading report...</Text>
        </View>
      </SafeAreaView>
    );
  }
  
  if (error || !report) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.errorContainer}>
          <AlertCircle size={64} color={Colors.error} style={styles.errorIcon} />
          <Text style={styles.errorTitle}>Report Not Found</Text>
          <Text style={styles.errorMessage}>
            {error || "The sentiment report you're looking for doesn't exist or has been deleted."}
          </Text>
          <Button
            title="Go Back"
            onPress={() => router.back()}
            variant="primary"
            style={styles.errorButton}
          />
        </View>
      </SafeAreaView>
    );
  }
  
  // Format the report text for better readability
  const formatReportText = (text: string) => {
    // Split by lines
    const lines = text.split('\n');
    
    // Process each line
    return lines.map((line, index) => {
      // Check if line is a section header (all caps or ends with a colon)
      const isSectionHeader = /^#+\s|^[A-Z][A-Z\s]+:?$/.test(line.trim()) || 
                             (line.trim().endsWith(':') && line.length < 50);
      
      // Check if line is a subsection or important point
      const isSubsection = /^[*-]\s/.test(line.trim()) || /^\d+\.\s/.test(line.trim());
      
      // Apply appropriate styling
      if (isSectionHeader) {
        return (
          <Text key={index} style={styles.sectionHeader}>
            {line}
          </Text>
        );
      } else if (isSubsection) {
        return (
          <Text key={index} style={styles.subsection}>
            {line}
          </Text>
        );
      } else if (line.trim() !== '') {
        return (
          <Text key={index} style={styles.normalText}>
            {line}
          </Text>
        );
      } else {
        // Return an empty text component for empty lines
        return <Text key={index}>{" "}</Text>;
      }
    });
  };
  
  const handleCopyReport = async () => {
    try {
      await navigator.clipboard.writeText(report.reportData.sentimentReport);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } catch (error) {
      console.error('Failed to copy report:', error);
      if (Platform.OS === 'web') {
        alert('Failed to copy report');
      } else {
        Alert.alert('Error', 'Failed to copy report');
      }
    }
  };
  
  const handleShareReport = async () => {
    try {
      if (Platform.OS === 'web') {
        alert('Sharing is not available on web');
        return;
      }
      
      await Share.share({
        message: `Sentiment Report for ${report.userInteractionSession.platformUrl}:\n\n${report.reportData.sentimentReport}`,
      });
    } catch (error) {
      console.error('Failed to share report:', error);
      Alert.alert('Error', 'Failed to share report');
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={styles.title}>Sentiment Report</Text>
          
          <Card variant="outlined" style={styles.infoCard}>
            <View style={styles.infoItem}>
              <User size={18} color={Colors.textSecondary} />
              <Text style={styles.infoText}>User ID: {report.userInteractionSession.userId}</Text>
            </View>
            
            <View style={styles.infoItem}>
              <Calendar size={18} color={Colors.textSecondary} />
              <Text style={styles.infoText}>
                Generated: {new Date(report.createdAt).toLocaleString()}
              </Text>
            </View>
            
            <View style={styles.infoItem}>
              <FileText size={18} color={Colors.textSecondary} />
              <Text style={styles.infoText} numberOfLines={1}>
                Platform: {report.userInteractionSession.platformUrl}
              </Text>
            </View>
          </Card>
        </View>
        
        <View style={styles.actions}>
          {Platform.OS === 'web' && (
            <Button
              title={copySuccess ? "Copied!" : "Copy Report"}
              onPress={handleCopyReport}
              variant={copySuccess ? "success" : "outline"}
              style={styles.actionButton}
              textStyle={copySuccess ? styles.copySuccessText : styles.actionButtonText}
              size="small"
            />
          )}
          
          {Platform.OS !== 'web' && (
            <Button
              title="Share Report"
              onPress={handleShareReport}
              variant="outline"
              style={styles.actionButton}
              textStyle={styles.actionButtonText}
              size="small"
            />
          )}
        </View>
        
        <Card variant="elevated" style={styles.reportCard}>
          <Text style={styles.reportTitle}>Analysis Results</Text>
          <View style={styles.reportTextContainer}>
            {formatReportText(report.reportData.sentimentReport)}
          </View>
        </Card>
        
        <View style={styles.buttonContainer}>
          <Button
            title="Back to Dashboard"
            onPress={() => router.push('/')}
            variant="primary"
            style={styles.button}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    padding: 16,
  },
  header: {
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 16,
  },
  infoCard: {
    marginBottom: 8,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: Colors.text,
    marginLeft: 8,
  },
  actions: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  actionButton: {
    marginRight: 8,
  },
  actionButtonText: {
    color: Colors.primary,
  },
  copySuccessText: {
    color: Colors.background,
  },
  reportCard: {
    marginBottom: 24,
  },
  reportTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 12,
  },
  reportTextContainer: {
    marginBottom: 8,
  },
  sectionHeader: {
    fontSize: 18,
    fontWeight: '700',
    color: Colors.text,
    marginTop: 16,
    marginBottom: 8,
  },
  subsection: {
    fontSize: 16,
    fontWeight: '500',
    color: Colors.text,
    marginTop: 8,
    marginBottom: 4,
  },
  normalText: {
    fontSize: 16,
    color: Colors.text,
    marginBottom: 4,
    lineHeight: 24,
  },
  buttonContainer: {
    marginBottom: 32,
  },
  button: {
    marginTop: 8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 18,
    color: Colors.textSecondary,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  errorIcon: {
    marginBottom: 16,
  },
  errorTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 8,
  },
  errorMessage: {
    fontSize: 16,
    color: Colors.textSecondary,
    textAlign: 'center',
    marginBottom: 24,
  },
  errorButton: {
    minWidth: 120,
  },
});