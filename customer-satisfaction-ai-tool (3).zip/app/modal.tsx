import React from 'react';
import { StyleSheet, Text, View, ScrollView, Linking } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaView } from 'react-native-safe-area-context';
import { FileText, MessageSquare, BarChart3, ArrowRight } from 'lucide-react-native';

import Colors from '@/constants/colors';
import Card from '@/components/Card';

export default function ModalScreen() {
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.title}>About CSAT AI Tool</Text>
        <Text style={styles.subtitle}>
          A powerful tool for understanding user satisfaction and gathering actionable insights
        </Text>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>How It Works</Text>
          
          <Card variant="elevated" style={styles.card}>
            <View style={styles.step}>
              <View style={styles.stepIconContainer}>
                <FileText size={24} color={Colors.primary} />
              </View>
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Step 1: Questionnaire Generation</Text>
                <Text style={styles.stepDescription}>
                  Our AI analyzes your platform and generates a tailored questionnaire to gather relevant user insights.
                </Text>
              </View>
            </View>
            
            <View style={styles.stepConnector} />
            
            <View style={styles.step}>
              <View style={styles.stepIconContainer}>
                <MessageSquare size={24} color={Colors.primary} />
              </View>
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Step 2: User Interaction</Text>
                <Text style={styles.stepDescription}>
                  Users respond to the questionnaire, providing valuable feedback about their experience with your platform.
                </Text>
              </View>
            </View>
            
            <View style={styles.stepConnector} />
            
            <View style={styles.step}>
              <View style={styles.stepIconContainer}>
                <BarChart3 size={24} color={Colors.primary} />
              </View>
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Step 3: Sentiment Analysis</Text>
                <Text style={styles.stepDescription}>
                  Our AI analyzes the responses to generate a comprehensive sentiment report with actionable insights.
                </Text>
              </View>
            </View>
          </Card>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Benefits</Text>
          
          <Card variant="elevated" style={styles.card}>
            <View style={styles.benefit}>
              <ArrowRight size={20} color={Colors.primary} style={styles.benefitIcon} />
              <Text style={styles.benefitText}>
                <Text style={styles.benefitHighlight}>Tailored Insights: </Text>
                Get platform-specific feedback that matters to your business
              </Text>
            </View>
            
            <View style={styles.benefit}>
              <ArrowRight size={20} color={Colors.primary} style={styles.benefitIcon} />
              <Text style={styles.benefitText}>
                <Text style={styles.benefitHighlight}>Sentiment Analysis: </Text>
                Understand the emotional aspects of user feedback
              </Text>
            </View>
            
            <View style={styles.benefit}>
              <ArrowRight size={20} color={Colors.primary} style={styles.benefitIcon} />
              <Text style={styles.benefitText}>
                <Text style={styles.benefitHighlight}>Actionable Reports: </Text>
                Receive clear recommendations for improving user satisfaction
              </Text>
            </View>
            
            <View style={styles.benefit}>
              <ArrowRight size={20} color={Colors.primary} style={styles.benefitIcon} />
              <Text style={styles.benefitText}>
                <Text style={styles.benefitHighlight}>Time Efficiency: </Text>
                Automate the process of creating relevant user research
              </Text>
            </View>
          </Card>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About the Technology</Text>
          
          <Card variant="elevated" style={styles.card}>
            <Text style={styles.techText}>
              The Customer Satisfaction AI Tool uses advanced AI models to generate questionnaires and analyze user sentiment. The tool leverages the power of large language models to understand context, generate relevant questions, and extract meaningful insights from user responses.
            </Text>
            
            <Text style={styles.techText}>
              This application is built with React Native and Expo, making it available across multiple platforms while maintaining a native feel and performance.
            </Text>
          </Card>
        </View>
        
        <View style={styles.footer}>
          <Text style={styles.footerText}>
            Customer Satisfaction AI Tool v1.0.0
          </Text>
          <Text style={styles.footerLink} onPress={() => Linking.openURL('https://example.com')}>
            Terms of Service
          </Text>
          <Text style={styles.footerLink} onPress={() => Linking.openURL('https://example.com')}>
            Privacy Policy
          </Text>
        </View>
      </ScrollView>
      
      <StatusBar style="auto" />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.textSecondary,
    marginBottom: 24,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 12,
  },
  card: {
    marginBottom: 8,
  },
  step: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  stepIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.primaryLight + '20', // 20% opacity
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  stepContent: {
    flex: 1,
  },
  stepTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 4,
  },
  stepDescription: {
    fontSize: 14,
    color: Colors.textSecondary,
    lineHeight: 20,
  },
  stepConnector: {
    width: 2,
    height: 24,
    backgroundColor: Colors.border,
    marginLeft: 24,
    marginBottom: 16,
  },
  benefit: {
    flexDirection: 'row',
    marginBottom: 12,
  },
  benefitIcon: {
    marginRight: 8,
    marginTop: 2,
  },
  benefitText: {
    fontSize: 14,
    color: Colors.text,
    flex: 1,
    lineHeight: 20,
  },
  benefitHighlight: {
    fontWeight: '600',
  },
  techText: {
    fontSize: 14,
    color: Colors.text,
    marginBottom: 12,
    lineHeight: 20,
  },
  footer: {
    marginTop: 16,
    marginBottom: 32,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 14,
    color: Colors.textSecondary,
    marginBottom: 8,
  },
  footerLink: {
    fontSize: 14,
    color: Colors.primary,
    marginBottom: 8,
  },
});