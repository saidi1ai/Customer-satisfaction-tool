import React, { useState } from 'react';
import { StyleSheet, Text, View, Switch, ScrollView, TextInput, Alert, Platform, TouchableOpacity, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Key, Moon, User, Info, Cpu, ChevronDown, Check } from 'lucide-react-native';

import Colors from '@/constants/colors';
import { useSettingsStore } from '@/store/settingsStore';
import Card from '@/components/Card';
import Button from '@/components/Button';
import { APP_NAME, APP_VERSION, AI_PROVIDERS } from '@/app/config';

export default function SettingsScreen() {
  const { 
    apiKey, 
    darkMode, 
    defaultUserId, 
    defaultAiProvider,
    updateApiKey, 
    toggleDarkMode, 
    updateDefaultUserId,
    updateDefaultAiProvider
  } = useSettingsStore();
  
  const [newApiKey, setNewApiKey] = useState(apiKey);
  const [newUserId, setNewUserId] = useState(defaultUserId);
  const [newAiProvider, setNewAiProvider] = useState(defaultAiProvider);
  const [apiKeySaved, setApiKeySaved] = useState(false);
  const [userIdSaved, setUserIdSaved] = useState(false);
  const [aiProviderSaved, setAiProviderSaved] = useState(false);
  const [showProviderModal, setShowProviderModal] = useState(false);

  const handleSaveApiKey = () => {
    updateApiKey(newApiKey);
    setApiKeySaved(true);
    setTimeout(() => setApiKeySaved(false), 2000);
    
    if (Platform.OS === 'web') {
      alert('API key saved successfully!');
    } else {
      Alert.alert('Success', 'API key saved successfully!');
    }
  };

  const handleSaveUserId = () => {
    updateDefaultUserId(newUserId);
    setUserIdSaved(true);
    setTimeout(() => setUserIdSaved(false), 2000);
    
    if (Platform.OS === 'web') {
      alert('User ID saved successfully!');
    } else {
      Alert.alert('Success', 'User ID saved successfully!');
    }
  };

  const handleSaveAiProvider = () => {
    updateDefaultAiProvider(newAiProvider);
    setAiProviderSaved(true);
    setTimeout(() => setAiProviderSaved(false), 2000);
    
    if (Platform.OS === 'web') {
      alert('Default AI provider saved successfully!');
    } else {
      Alert.alert('Success', 'Default AI provider saved successfully!');
    }
  };

  const selectProvider = (providerId: string) => {
    setNewAiProvider(providerId);
    setShowProviderModal(false);
  };

  const currentProviderName = AI_PROVIDERS.find(p => p.id === newAiProvider)?.name || 'Select Provider';

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={styles.title}>Settings</Text>
          <Text style={styles.subtitle}>Configure your application preferences</Text>
        </View>

        <Card variant="elevated" style={styles.card}>
          <View style={styles.settingGroup}>
            <View style={styles.settingHeader}>
              <Key size={20} color={Colors.primary} />
              <Text style={styles.settingTitle}>API Configuration</Text>
            </View>
            
            <View style={styles.settingItem}>
              <Text style={styles.settingLabel}>Gemini API Key</Text>
              <TextInput
                style={styles.apiKeyInput}
                value={newApiKey}
                onChangeText={setNewApiKey}
                placeholder="Enter your Gemini API key"
                placeholderTextColor={Colors.textTertiary}
                secureTextEntry={true}
                autoCapitalize="none"
                autoCorrect={false}
              />
              <Text style={styles.settingDescription}>
                Required for generating questionnaires. Get your API key from Google AI Studio.
              </Text>
              <Button
                title={apiKeySaved ? "Saved!" : "Save API Key"}
                onPress={handleSaveApiKey}
                variant={apiKeySaved ? "success" : "primary"}
                style={styles.saveButton}
                disabled={!newApiKey || newApiKey === apiKey}
              />
            </View>
          </View>
        </Card>

        <Card variant="elevated" style={styles.card}>
          <View style={styles.settingGroup}>
            <View style={styles.settingHeader}>
              <Cpu size={20} color={Colors.primary} />
              <Text style={styles.settingTitle}>AI Preferences</Text>
            </View>
            
            <View style={styles.settingItem}>
              <Text style={styles.settingLabel}>Default AI Provider</Text>
              <TouchableOpacity 
                style={styles.pickerButton}
                onPress={() => setShowProviderModal(true)}
              >
                <Text style={styles.pickerButtonText}>{currentProviderName}</Text>
                <ChevronDown size={20} color={Colors.text} />
              </TouchableOpacity>
              <Text style={styles.settingDescription}>
                Select your preferred AI provider for questionnaire generation.
              </Text>
              <Button
                title={aiProviderSaved ? "Saved!" : "Save Default Provider"}
                onPress={handleSaveAiProvider}
                variant={aiProviderSaved ? "success" : "primary"}
                style={styles.saveButton}
                disabled={!newAiProvider || newAiProvider === defaultAiProvider}
              />
              
              <Modal
                visible={showProviderModal}
                transparent={true}
                animationType="slide"
                onRequestClose={() => setShowProviderModal(false)}
              >
                <View style={styles.modalOverlay}>
                  <View style={styles.modalContent}>
                    <Text style={styles.modalTitle}>Select AI Provider</Text>
                    {AI_PROVIDERS.map((provider) => (
                      <TouchableOpacity
                        key={provider.id}
                        style={styles.providerOption}
                        onPress={() => selectProvider(provider.id)}
                      >
                        <Text style={styles.providerOptionText}>{provider.name}</Text>
                        {newAiProvider === provider.id && (
                          <Check size={20} color={Colors.primary} />
                        )}
                      </TouchableOpacity>
                    ))}
                    <Button
                      title="Cancel"
                      onPress={() => setShowProviderModal(false)}
                      variant="secondary"
                      style={styles.cancelButton}
                    />
                  </View>
                </View>
              </Modal>
            </View>
          </View>
        </Card>

        <Card variant="elevated" style={styles.card}>
          <View style={styles.settingGroup}>
            <View style={styles.settingHeader}>
              <User size={20} color={Colors.primary} />
              <Text style={styles.settingTitle}>User Preferences</Text>
            </View>
            
            <View style={styles.settingItem}>
              <Text style={styles.settingLabel}>Default User ID</Text>
              <TextInput
                style={styles.apiKeyInput}
                value={newUserId}
                onChangeText={setNewUserId}
                placeholder="Enter a user identifier"
                placeholderTextColor={Colors.textTertiary}
                autoCapitalize="none"
                autoCorrect={false}
              />
              <Text style={styles.settingDescription}>
                Used to identify your responses in sentiment analysis sessions.
              </Text>
              <Button
                title={userIdSaved ? "Saved!" : "Save User ID"}
                onPress={handleSaveUserId}
                variant={userIdSaved ? "success" : "primary"}
                style={styles.saveButton}
                disabled={!newUserId || newUserId === defaultUserId}
              />
            </View>
            
            <View style={styles.settingItem}>
              <View style={styles.switchContainer}>
                <Text style={styles.settingLabel}>Dark Mode</Text>
                <Switch
                  value={darkMode}
                  onValueChange={toggleDarkMode}
                  trackColor={{ false: Colors.border, true: Colors.primaryLight }}
                  thumbColor={darkMode ? Colors.primary : Colors.background}
                />
              </View>
              <Text style={styles.settingDescription}>
                Toggle between light and dark theme.
              </Text>
            </View>
          </View>
        </Card>

        <Card variant="elevated" style={styles.card}>
          <View style={styles.settingGroup}>
            <View style={styles.settingHeader}>
              <Info size={20} color={Colors.primary} />
              <Text style={styles.settingTitle}>About</Text>
            </View>
            
            <View style={styles.settingItem}>
              <Text style={styles.settingLabel}>Application</Text>
              <Text style={styles.settingValue}>{APP_NAME}</Text>
            </View>
            
            <View style={styles.settingItem}>
              <Text style={styles.settingLabel}>Version</Text>
              <Text style={styles.settingValue}>{APP_VERSION}</Text>
            </View>
          </View>
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    padding: 16,
  },
  header: {
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.textSecondary,
  },
  card: {
    marginBottom: 16,
  },
  settingGroup: {
    marginBottom: 8,
  },
  settingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  settingTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.text,
    marginLeft: 8,
  },
  settingItem: {
    marginBottom: 16,
  },
  settingLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: Colors.text,
    marginBottom: 8,
  },
  settingValue: {
    fontSize: 16,
    color: Colors.textSecondary,
  },
  settingDescription: {
    fontSize: 14,
    color: Colors.textTertiary,
    marginTop: 4,
  },
  apiKeyInput: {
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: Colors.text,
    backgroundColor: Colors.backgroundSecondary,
  },
  pickerButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    backgroundColor: Colors.backgroundSecondary,
    marginBottom: 4,
  },
  pickerButtonText: {
    fontSize: 16,
    color: Colors.text,
  },
  saveButton: {
    marginTop: 12,
  },
  switchContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    backgroundColor: Colors.background,
    borderRadius: 12,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 16,
    textAlign: 'center',
  },
  providerOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  providerOptionText: {
    fontSize: 16,
    color: Colors.text,
  },
  cancelButton: {
    marginTop: 16,
  },
});