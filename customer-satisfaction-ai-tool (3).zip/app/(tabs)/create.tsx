import React, { useState } from 'react';
import { StyleSheet, Text, View, ScrollView, Alert, Platform, TouchableOpacity, Modal } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Globe, ArrowRight, AlertCircle, Cpu, ChevronDown, Check } from 'lucide-react-native';

import Colors from '@/constants/colors';
import { useSettingsStore } from '@/store/settingsStore';
import Input from '@/components/Input';
import Button from '@/components/Button';
import Card from '@/components/Card';
import { jobsApi } from '@/services/apiService';
import { AI_PROVIDERS } from '@/app/config';

export default function CreateScreen() {
  const router = useRouter();
  const { apiKey, defaultAiProvider } = useSettingsStore();
  const [platformUrl, setPlatformUrl] = useState('');
  const [urlError, setUrlError] = useState('');
  const [aiProvider, setAiProvider] = useState(defaultAiProvider);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showProviderModal, setShowProviderModal] = useState(false);

  const validateUrl = (url: string) => {
    // Basic URL validation
    const urlPattern = /^(https?:\/\/)?(www\.)?[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)+(\/[a-zA-Z0-9-._~:/?#[\]@!$&'()*+,;=]*)?$/;
    
    if (!url) {
      setUrlError('Platform URL is required');
      return false;
    }
    
    if (!urlPattern.test(url)) {
      setUrlError('Please enter a valid URL');
      return false;
    }
    
    setUrlError('');
    return true;
  };

  const handleCreateJob = async () => {
    if (!validateUrl(platformUrl)) {
      return;
    }
    
    // Check if API key is configured
    if (!apiKey) {
      if (Platform.OS === 'web') {
        alert('Please configure your Gemini API key in the Settings tab before creating an analysis.');
      } else {
        Alert.alert(
          'API Key Required',
          'Please configure your Gemini API key in the Settings tab before creating an analysis.',
          [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Go to Settings', onPress: () => router.push('/settings') }
          ]
        );
      }
      return;
    }
    
    // Ensure URL has http/https prefix
    let formattedUrl = platformUrl;
    if (!formattedUrl.startsWith('http://') && !formattedUrl.startsWith('https://')) {
      formattedUrl = 'https://' + formattedUrl;
    }
    
    setIsLoading(true);
    setError(null);
    
    try {
      const job = await jobsApi.createJob(formattedUrl, aiProvider);
      
      if (job && job.questionnaireBlueprintId) {
        // Success - navigate to the questionnaire
        router.push(`/questionnaire/${job.questionnaireBlueprintId}`);
      } else if (job.errorMessage) {
        setError(job.errorMessage);
        if (Platform.OS === 'web') {
          alert(`Failed to create analysis: ${job.errorMessage}`);
        } else {
          Alert.alert('Error', `Failed to create analysis: ${job.errorMessage}`);
        }
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred';
      setError(errorMessage);
      
      if (Platform.OS === 'web') {
        alert(`Failed to create analysis: ${errorMessage}`);
      } else {
        Alert.alert('Error', `Failed to create analysis: ${errorMessage}`);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const selectProvider = (providerId: string) => {
    setAiProvider(providerId);
    setShowProviderModal(false);
  };

  const currentProviderName = AI_PROVIDERS.find(p => p.id === aiProvider)?.name || 'Select Provider';

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={styles.title}>Create New Analysis</Text>
          <Text style={styles.subtitle}>
            Enter a platform URL to generate a custom questionnaire for user research
          </Text>
        </View>
        
        <Card variant="elevated" style={styles.card}>
          <View style={styles.formGroup}>
            <Input
              label="Platform URL"
              placeholder="e.g., example.com"
              value={platformUrl}
              onChangeText={(text) => {
                setPlatformUrl(text);
                if (urlError) validateUrl(text);
              }}
              error={urlError}
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="url"
            />
            
            <View style={styles.aiProviderContainer}>
              <Text style={styles.aiProviderLabel}>AI Provider</Text>
              <TouchableOpacity 
                style={styles.pickerButton}
                onPress={() => setShowProviderModal(true)}
              >
                <Text style={styles.pickerButtonText}>{currentProviderName}</Text>
                <ChevronDown size={20} color={Colors.text} />
              </TouchableOpacity>
              <Text style={styles.aiProviderDescription}>
                {AI_PROVIDERS.find(p => p.id === aiProvider)?.description || ''}
              </Text>
            </View>
            
            <Button
              title="Generate Questionnaire"
              onPress={handleCreateJob}
              loading={isLoading}
              disabled={isLoading || !platformUrl}
              style={styles.button}
            />
          </View>
          
          {!apiKey && (
            <View style={styles.apiKeyWarning}>
              <AlertCircle size={20} color={Colors.warning} style={styles.warningIcon} />
              <Text style={styles.warningText}>
                API key not configured. Please set up your Gemini API key in Settings.
              </Text>
            </View>
          )}
          
          {error && (
            <View style={styles.errorContainer}>
              <AlertCircle size={20} color={Colors.error} style={styles.warningIcon} />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          )}
          
          <Modal
            visible={showProviderModal}
            transparent={true}
            animationType="slide"
            onRequestClose={() => setShowProviderModal(false)}
          >
            <View style={styles.modalOverlay}>
              <View style={styles.modalContent}>
                <Text style={styles.modalTitle}>Select AI Provider</Text>
                {AI_PROVIDERS.map((provider) => (
                  <TouchableOpacity
                    key={provider.id}
                    style={styles.providerOption}
                    onPress={() => selectProvider(provider.id)}
                  >
                    <Text style={styles.providerOptionText}>{provider.name}</Text>
                    {aiProvider === provider.id && (
                      <Check size={20} color={Colors.primary} />
                    )}
                  </TouchableOpacity>
                ))}
                <Button
                  title="Cancel"
                  onPress={() => setShowProviderModal(false)}
                  variant="secondary"
                  style={styles.cancelButton}
                />
              </View>
            </View>
          </Modal>
        </Card>
        
        <View style={styles.infoSection}>
          <Text style={styles.infoTitle}>How it works</Text>
          
          <View style={styles.step}>
            <View style={styles.stepIconContainer}>
              <Globe size={24} color={Colors.primary} />
            </View>
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>Step 1: URL Analysis</Text>
              <Text style={styles.stepDescription}>
                Our AI analyzes the platform to understand its purpose, features, and target audience.
              </Text>
            </View>
          </View>
          
          <View style={styles.stepConnector} />
          
          <View style={styles.step}>
            <View style={styles.stepIconContainer}>
              <Cpu size={24} color={Colors.primary} />
            </View>
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>Step 2: AI Processing</Text>
              <Text style={styles.stepDescription}>
                The selected AI provider processes the platform data to generate relevant questions.
              </Text>
            </View>
          </View>
          
          <View style={styles.stepConnector} />
          
          <View style={styles.step}>
            <View style={styles.stepIconContainer}>
              <ArrowRight size={24} color={Colors.primary} />
            </View>
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>Step 3: Questionnaire Generation</Text>
              <Text style={styles.stepDescription}>
                A tailored questionnaire is created to gather relevant user insights.
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    padding: 16,
  },
  header: {
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.textSecondary,
  },
  card: {
    marginBottom: 32,
  },
  formGroup: {
    marginBottom: 16,
  },
  aiProviderContainer: {
    marginTop: 16,
    marginBottom: 8,
  },
  aiProviderLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: Colors.text,
    marginBottom: 8,
  },
  pickerButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    backgroundColor: Colors.backgroundSecondary,
    marginBottom: 4,
  },
  pickerButtonText: {
    fontSize: 16,
    color: Colors.text,
  },
  aiProviderDescription: {
    fontSize: 14,
    color: Colors.textTertiary,
    marginBottom: 8,
  },
  button: {
    marginTop: 16,
  },
  apiKeyWarning: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.warningLight,
    padding: 12,
    borderRadius: 8,
    marginTop: 8,
  },
  warningIcon: {
    marginRight: 8,
  },
  warningText: {
    fontSize: 14,
    color: Colors.warningText,
    flex: 1,
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.errorLight,
    padding: 12,
    borderRadius: 8,
    marginTop: 8,
  },
  errorText: {
    fontSize: 14,
    color: Colors.errorText,
    flex: 1,
  },
  infoSection: {
    marginBottom: 32,
  },
  infoTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 16,
  },
  step: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  stepIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.primaryLight, // 20% opacity
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  stepContent: {
    flex: 1,
  },
  stepTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 4,
  },
  stepDescription: {
    fontSize: 14,
    color: Colors.textSecondary,
    lineHeight: 20,
  },
  stepConnector: {
    width: 2,
    height: 24,
    backgroundColor: Colors.border,
    marginLeft: 24,
    marginBottom: 16,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    backgroundColor: Colors.background,
    borderRadius: 12,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 16,
    textAlign: 'center',
  },
  providerOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  providerOptionText: {
    fontSize: 16,
    color: Colors.text,
  },
  cancelButton: {
    marginTop: 16,
  },
});