import React, { useState, useCallback, useEffect } from 'react';
import { StyleSheet, Text, View, FlatList, TouchableOpacity, RefreshControl, Alert, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { FileText, Users, Search, RefreshCw, Trash2, AlertCircle as AlertCircleIcon } from 'lucide-react-native';

import Colors from '@/constants/colors';
import { JobStatus, SessionStatus, PlatformAnalysisJob, UserInteractionSession } from '@/types';
import Card from '@/components/Card';
import StatusBadge from '@/components/StatusBadge';
import EmptyState from '@/components/EmptyState';
import Input from '@/components/Input';
import Button from '@/components/Button';
import { jobsApi, sessionsApi } from '@/services/apiService';

export default function ReportsScreen() {
  const router = useRouter();
  const [jobs, setJobs] = useState<PlatformAnalysisJob[]>([]);
  const [sessions, setSessions] = useState<UserInteractionSession[]>([]);
  const [activeTab, setActiveTab] = useState('questionnaires');
  const [searchQuery, setSearchQuery] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');

  // Fetch jobs and sessions
  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      const [jobsData, sessionsData] = await Promise.all([
        jobsApi.getJobs(),
        sessionsApi.getSessions()
      ]);
      
      setJobs(jobsData);
      setSessions(sessionsData);
    } catch (err) {
      console.error('Error fetching reports data:', err);
      setError(err instanceof Error ? err.message : 'Failed to load data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Filter and sort jobs
  const filteredJobs = jobs
    .filter(job => 
      job.platformUrl.toLowerCase().includes(searchQuery.toLowerCase()) &&
      (statusFilter === null || job.status === statusFilter)
    )
    .sort((a, b) => {
      const dateA = new Date(a.createdAt).getTime();
      const dateB = new Date(b.createdAt).getTime();
      return sortOrder === 'newest' ? dateB - dateA : dateA - dateB;
    });

  // Filter and sort sessions
  const filteredSessions = sessions
    .filter(session => 
      (session.userId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      session.platformUrl.toLowerCase().includes(searchQuery.toLowerCase())) &&
      (statusFilter === null || session.status === statusFilter)
    )
    .sort((a, b) => {
      const dateA = new Date(a.createdAt).getTime();
      const dateB = new Date(b.createdAt).getTime();
      return sortOrder === 'newest' ? dateB - dateA : dateA - dateB;
    });

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchData();
    setRefreshing(false);
  }, [fetchData]);

  const toggleSortOrder = () => {
    setSortOrder(sortOrder === 'newest' ? 'oldest' : 'newest');
  };

  const handleStatusFilter = (status: string | null) => {
    setStatusFilter(status === statusFilter ? null : status);
  };

  const handleRetryJob = async (jobId: string) => {
    try {
      const updatedJob = await jobsApi.retryJob(jobId);
      
      // Update the jobs list with the updated job
      setJobs(prevJobs => 
        prevJobs.map(job => job.id === jobId ? updatedJob : job)
      );
      
      if (updatedJob.questionnaireBlueprintId) {
        router.push(`/questionnaire/${updatedJob.questionnaireBlueprintId}`);
      }
    } catch (err) {
      console.error('Error retrying job:', err);
      const errorMessage = err instanceof Error ? err.message : 'Failed to retry job';
      
      if (Platform.OS === 'web') {
        alert(`Error: ${errorMessage}`);
      } else {
        Alert.alert('Error', errorMessage);
      }
    }
  };

  const handleDeleteJob = (jobId: string) => {
    const confirmDelete = async () => {
      try {
        await jobsApi.deleteJob(jobId);
        // Remove the job from the jobs list
        setJobs(prevJobs => prevJobs.filter(job => job.id !== jobId));
      } catch (err) {
        console.error('Error deleting job:', err);
        const errorMessage = err instanceof Error ? err.message : 'Failed to delete job';
        
        if (Platform.OS === 'web') {
          alert(`Error: ${errorMessage}`);
        } else {
          Alert.alert('Error', errorMessage);
        }
      }
    };

    if (Platform.OS === 'web') {
      if (confirm('Are you sure you want to delete this analysis?')) {
        confirmDelete();
      }
    } else {
      Alert.alert(
        'Delete Analysis',
        'Are you sure you want to delete this analysis? This action cannot be undone.',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Delete', onPress: confirmDelete, style: 'destructive' }
        ]
      );
    }
  };

  const handleDeleteSession = (sessionId: string) => {
    const confirmDelete = async () => {
      try {
        await sessionsApi.deleteSession(sessionId);
        // Remove the session from the sessions list
        setSessions(prevSessions => prevSessions.filter(session => session.id !== sessionId));
      } catch (err) {
        console.error('Error deleting session:', err);
        const errorMessage = err instanceof Error ? err.message : 'Failed to delete session';
        
        if (Platform.OS === 'web') {
          alert(`Error: ${errorMessage}`);
        } else {
          Alert.alert('Error', errorMessage);
        }
      }
    };

    if (Platform.OS === 'web') {
      if (confirm('Are you sure you want to delete this session?')) {
        confirmDelete();
      }
    } else {
      Alert.alert(
        'Delete Session',
        'Are you sure you want to delete this user session? This action cannot be undone.',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Delete', onPress: confirmDelete, style: 'destructive' }
        ]
      );
    }
  };

  if (loading && !refreshing && jobs.length === 0 && sessions.length === 0) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (error && jobs.length === 0 && sessions.length === 0) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.errorContainer}>
          <AlertCircleIcon size={64} color={Colors.error} style={styles.errorIcon} />
          <Text style={styles.errorTitle}>Error Loading Data</Text>
          <Text style={styles.errorMessage}>{error}</Text>
          <Button
            title="Try Again"
            onPress={fetchData}
            variant="primary"
            style={styles.errorButton}
          />
        </View>
      </SafeAreaView>
    );
  }

  const renderQuestionnaires = () => {
    if (filteredJobs.length === 0) {
      return (
        <EmptyState
          title="No questionnaires found"
          description={searchQuery || statusFilter ? "Try different search terms or filters" : "Create your first analysis to generate a questionnaire"}
          actionLabel={!searchQuery && !statusFilter ? "Create New Analysis" : undefined}
          onAction={!searchQuery && !statusFilter ? () => router.push('/create') : undefined}
          icon={<FileText size={64} color={Colors.textSecondary} />}
        />
      );
    }

    return (
      <FlatList
        data={filteredJobs}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Card variant="elevated" style={styles.card}>
            <TouchableOpacity 
              onPress={() => {
                if (item.questionnaireBlueprintId) {
                  router.push(`/questionnaire/${item.questionnaireBlueprintId}`);
                }
              }}
              disabled={!item.questionnaireBlueprintId && item.status !== JobStatus.FAILED}
              style={styles.cardContent}
            >
              <View style={styles.cardHeader}>
                <StatusBadge status={item.status} />
                <Text style={styles.cardDate}>
                  {new Date(item.createdAt).toLocaleDateString()}
                </Text>
              </View>
              <Text style={styles.cardTitle} numberOfLines={1}>
                {item.platformUrl}
              </Text>
              {item.errorMessage && (
                <Text style={styles.errorText} numberOfLines={2}>
                  Error: {item.errorMessage}
                </Text>
              )}
            </TouchableOpacity>
            
            <View style={styles.cardActions}>
              {item.status === JobStatus.FAILED && (
                <TouchableOpacity 
                  onPress={() => handleRetryJob(item.id)}
                  style={styles.actionButton}
                >
                  <RefreshCw size={18} color={Colors.primary} />
                  <Text style={styles.actionButtonText}>Retry</Text>
                </TouchableOpacity>
              )}
              
              <TouchableOpacity 
                onPress={() => handleDeleteJob(item.id)}
                style={[styles.actionButton, styles.deleteButton]}
              >
                <Trash2 size={18} color={Colors.error} />
                <Text style={styles.deleteButtonText}>Delete</Text>
              </TouchableOpacity>
            </View>
          </Card>
        )}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={[Colors.primary]}
            tintColor={Colors.primary}
          />
        }
      />
    );
  };

  const renderSessions = () => {
    if (filteredSessions.length === 0) {
      return (
        <EmptyState
          title="No user sessions found"
          description={searchQuery || statusFilter ? "Try different search terms or filters" : "No user sessions have been created yet"}
          icon={<Users size={64} color={Colors.textSecondary} />}
        />
      );
    }

    return (
      <FlatList
        data={filteredSessions}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Card variant="elevated" style={styles.card}>
            <TouchableOpacity 
              onPress={() => router.push(`/session/${item.id}`)}
              style={styles.cardContent}
            >
              <View style={styles.cardHeader}>
                <StatusBadge status={item.status} />
                <Text style={styles.cardDate}>
                  {new Date(item.createdAt).toLocaleDateString()}
                </Text>
              </View>
              <Text style={styles.cardTitle} numberOfLines={1}>
                User: {item.userId}
              </Text>
              <Text style={styles.cardSubtitle} numberOfLines={1}>
                Platform: {item.platformUrl}
              </Text>
              {item.errorMessage && (
                <Text style={styles.errorText} numberOfLines={2}>
                  Error: {item.errorMessage}
                </Text>
              )}
            </TouchableOpacity>
            
            <View style={styles.cardActions}>
              <TouchableOpacity 
                onPress={() => handleDeleteSession(item.id)}
                style={[styles.actionButton, styles.deleteButton]}
              >
                <Trash2 size={18} color={Colors.error} />
                <Text style={styles.deleteButtonText}>Delete</Text>
              </TouchableOpacity>
            </View>
          </Card>
        )}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={[Colors.primary]}
            tintColor={Colors.primary}
          />
        }
      />
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Reports</Text>
        
        <View style={styles.searchContainer}>
          <Input
            placeholder="Search..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            containerStyle={styles.searchInput}
            inputStyle={styles.searchInputField}
          />
          <Search size={20} color={Colors.textSecondary} style={styles.searchIcon} />
        </View>
        
        <View style={styles.filterContainer}>
          <View style={styles.filterButtons}>
            <TouchableOpacity
              style={[
                styles.filterButton,
                statusFilter === JobStatus.PENDING || statusFilter === SessionStatus.PENDING ? styles.activeFilterButton : null
              ]}
              onPress={() => handleStatusFilter(activeTab === 'questionnaires' ? JobStatus.PENDING : SessionStatus.PENDING)}
            >
              <Text style={[
                styles.filterButtonText,
                statusFilter === JobStatus.PENDING || statusFilter === SessionStatus.PENDING ? styles.activeFilterButtonText : null
              ]}>
                Pending
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.filterButton,
                statusFilter === JobStatus.ANALYZING || statusFilter === SessionStatus.IN_PROGRESS ? styles.activeFilterButton : null
              ]}
              onPress={() => handleStatusFilter(activeTab === 'questionnaires' ? JobStatus.ANALYZING : SessionStatus.IN_PROGRESS)}
            >
              <Text style={[
                styles.filterButtonText,
                statusFilter === JobStatus.ANALYZING || statusFilter === SessionStatus.IN_PROGRESS ? styles.activeFilterButtonText : null
              ]}>
                In Progress
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.filterButton,
                statusFilter === JobStatus.COMPLETED || statusFilter === SessionStatus.COMPLETED ? styles.activeFilterButton : null
              ]}
              onPress={() => handleStatusFilter(activeTab === 'questionnaires' ? JobStatus.COMPLETED : SessionStatus.COMPLETED)}
            >
              <Text style={[
                styles.filterButtonText,
                statusFilter === JobStatus.COMPLETED || statusFilter === SessionStatus.COMPLETED ? styles.activeFilterButtonText : null
              ]}>
                Completed
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.filterButton,
                statusFilter === JobStatus.FAILED || statusFilter === SessionStatus.FAILED ? styles.activeFilterButton : null
              ]}
              onPress={() => handleStatusFilter(activeTab === 'questionnaires' ? JobStatus.FAILED : SessionStatus.FAILED)}
            >
              <Text style={[
                styles.filterButtonText,
                statusFilter === JobStatus.FAILED || statusFilter === SessionStatus.FAILED ? styles.activeFilterButtonText : null
              ]}>
                Failed
              </Text>
            </TouchableOpacity>
          </View>
          
          <TouchableOpacity onPress={toggleSortOrder} style={styles.sortButton}>
            <Text style={styles.sortButtonText}>
              {sortOrder === 'newest' ? 'Newest First' : 'Oldest First'}
            </Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.tabs}>
          <TouchableOpacity
            style={[
              styles.tab,
              activeTab === 'questionnaires' && styles.activeTab
            ]}
            onPress={() => setActiveTab('questionnaires')}
          >
            <Text
              style={[
                styles.tabText,
                activeTab === 'questionnaires' && styles.activeTabText
              ]}
            >
              Questionnaires
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.tab,
              activeTab === 'sessions' && styles.activeTab
            ]}
            onPress={() => setActiveTab('sessions')}
          >
            <Text
              style={[
                styles.tabText,
                activeTab === 'sessions' && styles.activeTabText
              ]}
            >
              User Sessions
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.content}>
        {activeTab === 'questionnaires' ? renderQuestionnaires() : renderSessions()}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 16,
  },
  searchContainer: {
    position: 'relative',
    marginBottom: 16,
  },
  searchInput: {
    marginBottom: 0,
  },
  searchInputField: {
    paddingLeft: 40,
  },
  searchIcon: {
    position: 'absolute',
    left: 12,
    top: 12,
  },
  filterContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  filterButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  filterButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: Colors.backgroundSecondary,
    marginRight: 8,
    marginBottom: 8,
  },
  activeFilterButton: {
    backgroundColor: Colors.primaryLight,
  },
  filterButtonText: {
    fontSize: 12,
    color: Colors.textSecondary,
  },
  activeFilterButtonText: {
    color: Colors.background,
    fontWeight: '500',
  },
  sortButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: Colors.backgroundSecondary,
  },
  sortButtonText: {
    fontSize: 12,
    color: Colors.text,
  },
  tabs: {
    flexDirection: 'row',
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  activeTab: {
    borderBottomColor: Colors.primary,
  },
  tabText: {
    fontSize: 16,
    fontWeight: '500',
    color: Colors.textSecondary,
  },
  activeTabText: {
    color: Colors.primary,
  },
  content: {
    flex: 1,
  },
  listContent: {
    padding: 16,
  },
  card: {
    marginBottom: 12,
    padding: 0,
  },
  cardContent: {
    padding: 16,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: Colors.text,
    marginBottom: 4,
  },
  cardSubtitle: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  cardDate: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  errorText: {
    fontSize: 14,
    color: Colors.error,
    marginTop: 8,
  },
  cardActions: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    flex: 1,
  },
  actionButtonText: {
    marginLeft: 6,
    fontSize: 14,
    color: Colors.primary,
    fontWeight: '500',
  },
  deleteButton: {
    borderLeftWidth: 1,
    borderLeftColor: Colors.border,
  },
  deleteButtonText: {
    marginLeft: 6,
    fontSize: 14,
    color: Colors.error,
    fontWeight: '500',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 18,
    color: Colors.textSecondary,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  errorIcon: {
    marginBottom: 16,
  },
  errorTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 8,
  },
  errorMessage: {
    fontSize: 16,
    color: Colors.textSecondary,
    textAlign: 'center',
    marginBottom: 24,
  },
  errorButton: {
    minWidth: 120,
  },
});