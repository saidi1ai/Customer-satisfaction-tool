import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, RefreshControl, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { useTheme } from '@react-navigation/native';
import { Stack } from 'expo-router';
import { BarChart2, FileText, AlertCircle } from 'lucide-react-native';
import Card from '@/components/Card';
import StatusBadge from '@/components/StatusBadge';
import EmptyState from '@/components/EmptyState';
import { jobsApi } from '@/services/apiService';
import { PlatformAnalysisJob, JobStatus } from '@/types';
import Colors from '@/constants/colors';
import { trpc } from '@/lib/trpc';

export default function Dashboard() {
  const router = useRouter();
  const theme = useTheme();
  const [jobs, setJobs] = useState<PlatformAnalysisJob[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Use tRPC query
  const jobsQuery = trpc.jobs.getJobs.useQuery(undefined, {
    enabled: false, // Don't fetch automatically, we'll handle it manually
  });

  const loadJobs = async () => {
    try {
      setLoading(true);
      // Try to use tRPC query first
      if (jobsQuery.refetch) {
        const result = await jobsQuery.refetch();
        if (result.data) {
          setJobs(result.data);
        }
      } else {
        // Fall back to regular API call
        const jobsData = await jobsApi.getJobs();
        setJobs(jobsData);
      }
    } catch (error) {
      console.error('Error loading jobs:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadJobs();
  }, []);

  useEffect(() => {
    loadJobs();
  }, []);

  const navigateToJob = (job: PlatformAnalysisJob) => {
    if (job.status === JobStatus.COMPLETED && job.questionnaireBlueprintId) {
      router.push(`/questionnaire/${job.questionnaireBlueprintId}`);
    } else {
      // Could show a message that the job is not ready yet
      console.log('Job not ready for viewing');
    }
  };

  const renderJobItem = ({ item: job }: { item: PlatformAnalysisJob }) => (
    <TouchableOpacity onPress={() => navigateToJob(job)}>
      <Card style={styles.jobCard}>
        <View style={styles.jobHeader}>
          <Text style={[styles.jobName, { color: theme.colors.text }]} numberOfLines={1}>
            {job.platformUrl}
          </Text>
          <StatusBadge status={job.status} />
        </View>
        
        <Text style={[styles.jobUrl, { color: theme.colors.text }]} numberOfLines={1}>
          {job.platformUrl}
        </Text>
        
        <View style={styles.jobFooter}>
          <View style={styles.jobStats}>
            {job.status === JobStatus.COMPLETED && job.questionnaireBlueprintId ? (
              <View style={styles.statItem}>
                <FileText size={16} color={theme.colors.text} style={styles.statIcon} />
                <Text style={[styles.statText, { color: theme.colors.text }]}>
                  Questionnaire ready
                </Text>
              </View>
            ) : job.status === JobStatus.FAILED ? (
              <View style={styles.statItem}>
                <AlertCircle size={16} color={Colors.error} style={styles.statIcon} />
                <Text style={[styles.statText, { color: Colors.error }]}>
                  {job.errorMessage || 'Failed to generate'}
                </Text>
              </View>
            ) : null}
          </View>
          
          <Text style={[styles.jobDate, { color: theme.colors.text }]}>
            {new Date(job.createdAt).toLocaleDateString()}
          </Text>
        </View>
      </Card>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <Stack.Screen
        options={{
          title: 'Dashboard',
          headerStyle: {
            backgroundColor: theme.colors.card,
          },
          headerTintColor: theme.colors.text,
        }}
      />
      
      <FlatList
        data={jobs}
        renderItem={renderJobItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={[theme.colors.primary]}
            tintColor={theme.colors.primary}
          />
        }
        ListEmptyComponent={
          !loading ? (
            <EmptyState
              title="No analysis jobs yet"
              description="Create a new job to analyze a platform and generate a questionnaire."
              actionLabel="Create New Job"
              onAction={() => router.push('/create')}
              icon={<BarChart2 size={48} color={theme.colors.text} />}
            />
          ) : null
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listContent: {
    padding: 16,
    flexGrow: 1,
  },
  jobCard: {
    marginBottom: 16,
    padding: 16,
  },
  jobHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  jobName: {
    fontSize: 18,
    fontWeight: 'bold',
    flex: 1,
    marginRight: 8,
  },
  jobUrl: {
    fontSize: 14,
    marginBottom: 12,
  },
  jobFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  jobStats: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  statIcon: {
    marginRight: 4,
  },
  statText: {
    fontSize: 14,
  },
  jobDate: {
    fontSize: 12,
  },
});