import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, ScrollView, Share, Platform, Alert } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Copy, Share2, User, ArrowRight, AlertCircle } from 'lucide-react-native';

import Colors from '@/constants/colors';
import { useSettingsStore } from '@/store/settingsStore';
import Card from '@/components/Card';
import Button from '@/components/Button';
import Input from '@/components/Input';
import { questionnairesApi, sessionsApi } from '@/services/apiService';

export default function QuestionnaireDetailScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const { defaultUserId } = useSettingsStore();
  
  const [userId, setUserId] = useState(defaultUserId);
  const [userIdError, setUserIdError] = useState('');
  const [isCreatingSession, setIsCreatingSession] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);
  const [questionnaire, setQuestionnaire] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    const fetchQuestionnaire = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const data = await questionnairesApi.getQuestionnaire(id as string);
        setQuestionnaire(data);
      } catch (err) {
        console.error('Error fetching questionnaire:', err);
        setError(err instanceof Error ? err.message : 'Failed to load questionnaire');
      } finally {
        setLoading(false);
      }
    };
    
    fetchQuestionnaire();
  }, [id]);
  
  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading questionnaire...</Text>
        </View>
      </SafeAreaView>
    );
  }
  
  if (error || !questionnaire) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.errorContainer}>
          <AlertCircle size={64} color={Colors.error} style={styles.errorIcon} />
          <Text style={styles.errorTitle}>Questionnaire Not Found</Text>
          <Text style={styles.errorMessage}>
            {error || "The questionnaire you're looking for doesn't exist or has been deleted."}
          </Text>
          <Button
            title="Go Back"
            onPress={() => router.back()}
            variant="primary"
            style={styles.errorButton}
          />
        </View>
      </SafeAreaView>
    );
  }
  
  // Format the questionnaire text for better readability
  const formatQuestionnaireText = (text: string) => {
    // Split by lines
    const lines = text.split('\n');
    
    // Process each line
    return lines.map((line, index) => {
      // Check if line is a section header (all caps or ends with a colon)
      const isSectionHeader = /^[A-Z\s]+:?$/.test(line.trim()) || line.trim().endsWith(':');
      
      // Check if line is a question (starts with a number followed by a period or has a question mark)
      const isQuestion = /^\d+\./.test(line.trim()) || line.includes('?');
      
      // Apply appropriate styling
      if (isSectionHeader) {
        return (
          <Text key={index} style={styles.sectionHeader}>
            {line}
          </Text>
        );
      } else if (isQuestion) {
        return (
          <Text key={index} style={styles.question}>
            {line}
          </Text>
        );
      } else if (line.trim() !== '') {
        return (
          <Text key={index} style={styles.normalText}>
            {line}
          </Text>
        );
      } else {
        // Return an empty text component for empty lines
        return <Text key={index}>{" "}</Text>;
      }
    });
  };
  
  const handleCopyQuestionnaire = async () => {
    try {
      await navigator.clipboard.writeText(questionnaire.questionnaireText);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } catch (error) {
      console.error('Failed to copy questionnaire:', error);
      if (Platform.OS === 'web') {
        alert('Failed to copy questionnaire');
      } else {
        Alert.alert('Error', 'Failed to copy questionnaire');
      }
    }
  };
  
  const handleShareQuestionnaire = async () => {
    try {
      if (Platform.OS === 'web') {
        alert('Sharing is not available on web');
        return;
      }
      
      await Share.share({
        message: `Questionnaire for ${questionnaire.platformAnalysisJob.platformUrl}:\n\n${questionnaire.questionnaireText}`,
      });
    } catch (error) {
      console.error('Failed to share questionnaire:', error);
      Alert.alert('Error', 'Failed to share questionnaire');
    }
  };
  
  const validateUserId = () => {
    if (!userId.trim()) {
      setUserIdError('User ID is required');
      return false;
    }
    
    setUserIdError('');
    return true;
  };
  
  const handleCreateSession = async () => {
    if (!validateUserId()) {
      return;
    }
    
    setIsCreatingSession(true);
    
    try {
      const session = await sessionsApi.createSession(
        userId,
        questionnaire.id,
        questionnaire.platformAnalysisJob.platformUrl
      );
      
      router.push(`/session/${session.id}`);
    } catch (error) {
      console.error('Failed to create session:', error);
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      
      if (Platform.OS === 'web') {
        alert(`Failed to create user session: ${errorMessage}`);
      } else {
        Alert.alert('Error', `Failed to create user session: ${errorMessage}`);
      }
    } finally {
      setIsCreatingSession(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={styles.platformUrl}>{questionnaire.platformAnalysisJob.platformUrl}</Text>
          <Text style={styles.createdAt}>
            Created on {new Date(questionnaire.createdAt).toLocaleDateString()}
          </Text>
        </View>
        
        <View style={styles.actions}>
          {Platform.OS === 'web' && (
            <Button
              title={copySuccess ? "Copied!" : "Copy"}
              onPress={handleCopyQuestionnaire}
              variant={copySuccess ? "success" : "outline"}
              style={styles.actionButton}
              textStyle={copySuccess ? styles.copySuccessText : styles.actionButtonText}
              size="small"
            />
          )}
          
          {Platform.OS !== 'web' && (
            <Button
              title="Share"
              onPress={handleShareQuestionnaire}
              variant="outline"
              style={styles.actionButton}
              textStyle={styles.actionButtonText}
              size="small"
            />
          )}
        </View>
        
        <Card variant="elevated" style={styles.questionnaireCard}>
          <Text style={styles.questionnaireTitle}>Generated Questionnaire</Text>
          <View style={styles.questionnaireTextContainer}>
            {formatQuestionnaireText(questionnaire.questionnaireText)}
          </View>
        </Card>
        
        <Card variant="elevated" style={styles.sessionCard}>
          <Text style={styles.sessionTitle}>Create User Session</Text>
          <Text style={styles.sessionDescription}>
            Start a new user session to collect responses and generate a sentiment report
          </Text>
          
          <View style={styles.userIdContainer}>
            <User size={20} color={Colors.textSecondary} style={styles.userIdIcon} />
            <Input
              placeholder="Enter user ID"
              value={userId}
              onChangeText={(text) => {
                setUserId(text);
                if (userIdError) validateUserId();
              }}
              error={userIdError}
              containerStyle={styles.userIdInput}
            />
          </View>
          
          <Button
            title="Start User Session"
            onPress={handleCreateSession}
            loading={isCreatingSession}
            disabled={isCreatingSession}
            style={styles.sessionButton}
          />
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    padding: 16,
  },
  header: {
    marginBottom: 16,
  },
  platformUrl: {
    fontSize: 20,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 4,
  },
  createdAt: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  actions: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  actionButton: {
    marginRight: 8,
  },
  actionButtonText: {
    color: Colors.primary,
  },
  copySuccessText: {
    color: Colors.background,
  },
  questionnaireCard: {
    marginBottom: 24,
  },
  questionnaireTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 12,
  },
  questionnaireTextContainer: {
    marginBottom: 8,
  },
  sectionHeader: {
    fontSize: 16,
    fontWeight: '700',
    color: Colors.text,
    marginTop: 16,
    marginBottom: 8,
  },
  question: {
    fontSize: 16,
    fontWeight: '500',
    color: Colors.text,
    marginTop: 12,
    marginBottom: 4,
  },
  normalText: {
    fontSize: 16,
    color: Colors.text,
    marginBottom: 4,
    lineHeight: 24,
  },
  sessionCard: {
    marginBottom: 24,
  },
  sessionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 8,
  },
  sessionDescription: {
    fontSize: 14,
    color: Colors.textSecondary,
    marginBottom: 16,
  },
  userIdContainer: {
    position: 'relative',
    marginBottom: 16,
  },
  userIdIcon: {
    position: 'absolute',
    left: 12,
    top: 14,
    zIndex: 1,
  },
  userIdInput: {
    marginBottom: 0,
  },
  sessionButton: {
    marginTop: 8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 18,
    color: Colors.textSecondary,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  errorIcon: {
    marginBottom: 16,
  },
  errorTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 8,
  },
  errorMessage: {
    fontSize: 16,
    color: Colors.textSecondary,
    textAlign: 'center',
    marginBottom: 24,
  },
  errorButton: {
    minWidth: 120,
  },
});