// API configuration
export const API_BASE_URL = process.env.EXPO_PUBLIC_API_BASE_URL || 'http://localhost:3000';

// AI API Keys
export const GEMINI_API_KEY = process.env.EXPO_PUBLIC_GEMINI_API_KEY || '';
export const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
export const GROQ_API_KEY = process.env.GROQ_API_KEY || '';
export const HUME_API_KEY = process.env.EXPO_PUBLIC_HUME_API_KEY || '';

// Supabase configuration
export const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL || '';
export const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '';

// App configuration
export const APP_NAME = 'SentimentSense';
export const APP_VERSION = '1.0.0';

// Feature flags
export const FEATURES = {
  ANALYTICS: true,
  NOTIFICATIONS: true,
  OFFLINE_MODE: false,
};

// Default settings
export const DEFAULT_SETTINGS = {
  theme: 'system',
  notifications: true,
  language: 'en',
  aiProvider: 'gemini',
};

// Timeouts
export const TIMEOUTS = {
  API_REQUEST: 30000, // 30 seconds
  SESSION_EXPIRY: 3600000, // 1 hour
};

// AI Providers
export const AI_PROVIDERS = [
  { id: 'gemini', name: 'Google Gemini', description: 'Google\'s multimodal AI model' },
  { id: 'openai', name: 'OpenAI GPT-4o', description: 'OpenAI\'s latest multimodal model' },
  { id: 'groq', name: 'Groq LLaMA 3', description: 'Ultra-fast LLaMA 3 inference' },
];