import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import { useLocalSearchParams, Stack, useRouter } from 'expo-router';
import { useTheme } from '@react-navigation/native';
import { ArrowLeft, MessageSquare, BarChart, Heart, AlertCircle } from 'lucide-react-native';
import Card from '@/components/Card';
import StatusBadge from '@/components/StatusBadge';
import Button from '@/components/Button';
import supabase from '@/lib/supabase';
import { sessionsApi } from '@/services/apiService';
import { UserInteractionSession, SessionStatus, SentimentReport, QuestionnaireBlueprint } from '@/types';
import Colors from '@/constants/colors';

// Extended session type that includes related data
interface ExtendedSession extends UserInteractionSession {
  questionnaireBlueprint?: QuestionnaireBlueprint;
  sentimentReport?: SentimentReport;
}

export default function SessionDetails() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const theme = useTheme();
  const [session, setSession] = useState<ExtendedSession | null>(null);
  const [loading, setLoading] = useState(true);

  const loadSession = async () => {
    try {
      if (!id) return;
      const sessionData = await sessionsApi.getSession(id.toString());
      setSession(sessionData as ExtendedSession);
    } catch (error) {
      console.error('Error loading session:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSession();

    // Set up Supabase Realtime subscription for session updates
    const channel = supabase
      .channel('session-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'UserInteractionSession',
          filter: `id=eq.${id}`,
        },
        (payload: any) => {
          console.log('Session change received:', payload);
          // Refresh the session data when changes occur
          loadSession();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [id]);

  const navigateToReport = () => {
    if (session?.sentimentReportId) {
      router.push(`/report/${session.id}`);
    }
  };

  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.colors.background }]}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  if (!session) {
    return (
      <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
        <Stack.Screen
          options={{
            title: 'Session Not Found',
            headerStyle: {
              backgroundColor: theme.colors.card,
            },
            headerTintColor: theme.colors.text,
            headerLeft: () => (
              <Button
                onPress={() => router.back()}
                variant="outline"
                title=""
                icon={<ArrowLeft size={20} color={theme.colors.text} />}
              />
            ),
          }}
        />
        <View style={styles.errorContainer}>
          <AlertCircle size={48} color={Colors.error} />
          <Text style={[styles.errorText, { color: theme.colors.text }]}>
            Session not found or has been deleted.
          </Text>
          <Button
            title="Go Back"
            onPress={() => router.back()}
            variant="primary"
            style={styles.errorButton}
          />
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <Stack.Screen
        options={{
          title: 'Session Details',
          headerStyle: {
            backgroundColor: theme.colors.card,
          },
          headerTintColor: theme.colors.text,
          headerLeft: () => (
            <Button
              onPress={() => router.back()}
              variant="outline"
              title=""
              icon={<ArrowLeft size={20} color={theme.colors.text} />}
            />
          ),
        }}
      />

      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
        <Card style={styles.headerCard}>
          <View style={styles.headerRow}>
            <Text style={[styles.sessionTitle, { color: theme.colors.text }]}>
              Session with User {session.userId}
            </Text>
            <StatusBadge status={session.status} />
          </View>
          
          <Text style={[styles.sessionDate, { color: theme.colors.text }]}>
            {new Date(session.createdAt).toLocaleString()}
          </Text>
          
          {session.status === SessionStatus.IN_PROGRESS && (
            <View style={styles.inProgressContainer}>
              <ActivityIndicator size="small" color={theme.colors.primary} style={styles.inProgressSpinner} />
              <Text style={[styles.inProgressText, { color: theme.colors.text }]}>
                Session is currently in progress with Hume AI
              </Text>
            </View>
          )}
          
          {session.status === SessionStatus.FAILED && (
            <View style={styles.errorMessageContainer}>
              <AlertCircle size={16} color={Colors.error} style={styles.errorIcon} />
              <Text style={[styles.errorMessage, { color: Colors.error }]}>
                {session.errorMessage || "An error occurred during the session"}
              </Text>
            </View>
          )}
        </Card>

        {session.status === SessionStatus.COMPLETED && session.sentimentReport && (
          <Card style={styles.reportCard}>
            <View style={styles.reportHeader}>
              <BarChart size={20} color={theme.colors.text} style={styles.reportIcon} />
              <Text style={[styles.reportTitle, { color: theme.colors.text }]}>
                Sentiment Report Available
              </Text>
            </View>
            
            <View style={styles.reportPreview}>
              <View style={styles.sentimentScore}>
                <Text style={[styles.scoreLabel, { color: theme.colors.text }]}>
                  Overall Sentiment
                </Text>
                <View style={styles.scoreContainer}>
                  <Heart 
                    size={24} 
                    color={getSentimentColor(session.sentimentReport.overallSentiment, theme)} 
                    fill={getSentimentColor(session.sentimentReport.overallSentiment, theme)}
                  />
                  <Text style={[styles.scoreValue, { color: theme.colors.text }]}>
                    {(session.sentimentReport.overallSentiment * 10).toFixed(1)}
                  </Text>
                </View>
              </View>
              
              <View style={styles.insightsPreview}>
                <Text style={[styles.insightsLabel, { color: theme.colors.text }]}>
                  Key Insights
                </Text>
                {session.sentimentReport.keyInsights.slice(0, 2).map((insight: string, index: number) => (
                  <Text 
                    key={index} 
                    style={[styles.insightItem, { color: theme.colors.text }]}
                    numberOfLines={1}
                  >
                    • {insight}
                  </Text>
                ))}
                {session.sentimentReport.keyInsights.length > 2 && (
                  <Text style={[styles.moreInsights, { color: theme.colors.primary }]}>
                    +{session.sentimentReport.keyInsights.length - 2} more insights
                  </Text>
                )}
              </View>
            </View>
            
            <Button
              title="View Full Report"
              onPress={navigateToReport}
              variant="primary"
              style={styles.viewReportButton}
            />
          </Card>
        )}

        <Card style={styles.questionnaireCard}>
          <View style={styles.questionnaireHeader}>
            <MessageSquare size={20} color={theme.colors.text} style={styles.questionnaireIcon} />
            <Text style={[styles.questionnaireTitle, { color: theme.colors.text }]}>
              {session.questionnaireBlueprint?.title || "Questionnaire"}
            </Text>
          </View>
          
          <Text style={[styles.questionnaireDescription, { color: theme.colors.text }]}>
            {session.questionnaireBlueprint?.description || "No description available"}
          </Text>
          
          <View style={styles.questionsContainer}>
            {session.questionnaireBlueprint?.questions?.map((question: any, index: number) => (
              <View key={question.id} style={styles.questionItem}>
                <Text style={[styles.questionNumber, { color: theme.colors.text }]}>
                  Q{index + 1}
                </Text>
                <View style={styles.questionContent}>
                  <Text style={[styles.questionText, { color: theme.colors.text }]}>
                    {question.text}
                  </Text>
                  <Text style={[styles.questionType, { color: theme.colors.text }]}>
                    {formatQuestionType(question.type)}
                  </Text>
                </View>
              </View>
            ))}
          </View>
        </Card>
      </ScrollView>
    </View>
  );
}

// Helper function to get color based on sentiment score
function getSentimentColor(score: number, theme: any) {
  if (score >= 0.7) return '#4CAF50'; // Positive
  if (score >= 0.4) return '#FFC107'; // Neutral
  return '#F44336'; // Negative
}

// Helper function to format question type
function formatQuestionType(type: string) {
  switch (type) {
    case 'multiple_choice':
      return 'Multiple Choice';
    case 'open_ended':
      return 'Open Ended';
    case 'rating':
      return 'Rating (1-5)';
    default:
      return type;
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  headerCard: {
    marginBottom: 16,
    padding: 16,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  sessionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    flex: 1,
    marginRight: 8,
  },
  sessionDate: {
    fontSize: 14,
    marginBottom: 8,
  },
  inProgressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    padding: 8,
    backgroundColor: 'rgba(33, 150, 243, 0.1)',
    borderRadius: 8,
  },
  inProgressSpinner: {
    marginRight: 8,
  },
  inProgressText: {
    fontSize: 14,
  },
  errorMessageContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    padding: 8,
    backgroundColor: 'rgba(244, 67, 54, 0.1)',
    borderRadius: 8,
  },
  errorIcon: {
    marginRight: 8,
  },
  errorMessage: {
    fontSize: 14,
    flex: 1,
  },
  reportCard: {
    marginBottom: 16,
    padding: 16,
  },
  reportHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  reportIcon: {
    marginRight: 8,
  },
  reportTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  reportPreview: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  sentimentScore: {
    flex: 1,
    borderRightWidth: 1,
    borderRightColor: 'rgba(0, 0, 0, 0.1)',
    paddingRight: 16,
  },
  scoreLabel: {
    fontSize: 14,
    marginBottom: 4,
  },
  scoreContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  scoreValue: {
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  insightsPreview: {
    flex: 2,
    paddingLeft: 16,
  },
  insightsLabel: {
    fontSize: 14,
    marginBottom: 4,
  },
  insightItem: {
    fontSize: 14,
    marginBottom: 2,
  },
  moreInsights: {
    fontSize: 12,
    marginTop: 4,
  },
  viewReportButton: {
    marginTop: 8,
  },
  questionnaireCard: {
    marginBottom: 16,
    padding: 16,
  },
  questionnaireHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  questionnaireIcon: {
    marginRight: 8,
  },
  questionnaireTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  questionnaireDescription: {
    fontSize: 14,
    marginBottom: 16,
  },
  questionsContainer: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(0, 0, 0, 0.1)',
    paddingTop: 12,
  },
  questionItem: {
    flexDirection: 'row',
    marginBottom: 12,
  },
  questionNumber: {
    width: 30,
    fontSize: 14,
    fontWeight: 'bold',
  },
  questionContent: {
    flex: 1,
  },
  questionText: {
    fontSize: 14,
    marginBottom: 4,
  },
  questionType: {
    fontSize: 12,
    opacity: 0.7,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 16,
    marginBottom: 24,
  },
  errorButton: {
    minWidth: 120,
  },
});