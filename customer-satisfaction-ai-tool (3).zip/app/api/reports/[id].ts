import prisma from '@/lib/prisma';

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const report = await prisma.sentimentReport.findUnique({
      where: { id: params.id },
    });
    
    if (!report) {
      return new Response(
        JSON.stringify({ error: 'Report not found' }),
        { status: 404, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    return new Response(
      JSON.stringify(report),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error(`Error fetching report ${params.id}:`, error);
    return new Response(
      JSON.stringify({ error: 'Failed to fetch report' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}