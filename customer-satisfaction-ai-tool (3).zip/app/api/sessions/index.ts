import prisma from '@/lib/prisma';
import { initiateHumeSession } from '@/services/aiService';

export async function GET(request: Request) {
  try {
    const sessions = await prisma.userInteractionSession.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        questionnaireBlueprint: true,
        sentimentReport: true,
      },
    });

    return new Response(JSON.stringify(sessions), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Error fetching sessions:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Internal server error' 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function POST(request: Request) {
  try {
    const { userId, questionnaireBlueprintId, platformUrl } = await request.json();

    if (!userId) {
      return new Response(JSON.stringify({ error: 'User ID is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    if (!questionnaireBlueprintId) {
      return new Response(JSON.stringify({ error: 'Questionnaire ID is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    if (!platformUrl) {
      return new Response(JSON.stringify({ error: 'Platform URL is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Create a new session with PENDING status
    const session = await prisma.userInteractionSession.create({
      data: {
        userId,
        questionnaireBlueprintId,
        platformUrl,
        status: 'PENDING',
        responses: {},
      },
    });

    // Start the Hume session initiation process
    try {
      // Initiate the Hume session
      const humeSessionId = await initiateHumeSession(questionnaireBlueprintId, userId);
      
      // Update the session with the Hume session ID and change status to IN_PROGRESS
      const updatedSession = await prisma.userInteractionSession.update({
        where: {
          id: session.id,
        },
        data: {
          humeSessionId,
          status: 'IN_PROGRESS',
        },
      });
      
      return new Response(JSON.stringify(updatedSession), {
        status: 201,
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (error) {
      // Update the session status to FAILED
      const updatedSession = await prisma.userInteractionSession.update({
        where: {
          id: session.id,
        },
        data: {
          status: 'FAILED',
          errorMessage: error instanceof Error ? error.message : 'Failed to initiate Hume session',
        },
      });
      
      return new Response(JSON.stringify({
        error: error instanceof Error ? error.message : 'Failed to initiate Hume session',
        session: updatedSession,
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
  } catch (error) {
    console.error('Error creating session:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Internal server error' 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}