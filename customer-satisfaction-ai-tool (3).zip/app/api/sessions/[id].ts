import prisma from '@/lib/prisma';
import { generateSentimentReport } from '@/services/aiService';

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await prisma.userInteractionSession.findUnique({
      where: { id: params.id },
      include: {
        questionnaireBlueprint: true,
        sentimentReport: true,
      },
    });
    
    if (!session) {
      return new Response(
        JSON.stringify({ error: 'Session not found' }),
        { status: 404, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    return new Response(
      JSON.stringify(session),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error(`Error fetching session ${params.id}:`, error);
    return new Response(
      JSON.stringify({ error: 'Failed to fetch session' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    // Check if session exists
    const session = await prisma.userInteractionSession.findUnique({
      where: { id: params.id },
    });
    
    if (!session) {
      return new Response(
        JSON.stringify({ error: 'Session not found' }),
        { status: 404, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    // Delete the session (this will cascade delete the sentiment report due to our schema)
    await prisma.userInteractionSession.delete({
      where: { id: params.id },
    });
    
    return new Response(
      JSON.stringify({ success: true }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error(`Error deleting session ${params.id}:`, error);
    return new Response(
      JSON.stringify({ error: 'Failed to delete session' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const { action, responses } = body;
    
    // Get the session
    const session = await prisma.userInteractionSession.findUnique({
      where: { id: params.id },
      include: {
        questionnaireBlueprint: true,
      },
    });
    
    if (!session) {
      return new Response(
        JSON.stringify({ error: 'Session not found' }),
        { status: 404, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    if (action === 'updateResponses' && responses) {
      // Update the session responses
      const updatedSession = await prisma.userInteractionSession.update({
        where: { id: params.id },
        data: {
          responses: responses,
        },
      });
      
      return new Response(
        JSON.stringify(updatedSession),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    } 
    else if (action === 'updateStatus') {
      const { status, errorMessage } = body;
      
      // Update the session status
      const updatedSession = await prisma.userInteractionSession.update({
        where: { id: params.id },
        data: {
          status: status,
          errorMessage: errorMessage || null,
        },
      });
      
      return new Response(
        JSON.stringify(updatedSession),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    }
    else if (action === 'generateReport' || action === 'retryReport') {
      // Check if we have the questionnaire and responses
      if (!session.questionnaireBlueprint) {
        return new Response(
          JSON.stringify({ error: 'Questionnaire not found for this session' }),
          { status: 400, headers: { 'Content-Type': 'application/json' } }
        );
      }
      
      if (!session.responses || Object.keys(session.responses).length === 0) {
        return new Response(
          JSON.stringify({ error: 'No responses found for this session' }),
          { status: 400, headers: { 'Content-Type': 'application/json' } }
        );
      }
      
      // Update session status to PROCESSING
      await prisma.userInteractionSession.update({
        where: { id: params.id },
        data: {
          status: 'PROCESSING',
          errorMessage: null,
        },
      });
      
      try {
        // Generate the sentiment report
        const result = await generateSentimentReport(
          session.questionnaireBlueprint.questionnaireText,
          session.responses as Record<string, string>
        );
        
        if (result.success && result.data) {
          // If there's an existing report, update it
          if (session.sentimentReportId) {
            await prisma.sentimentReport.update({
              where: { id: session.sentimentReportId },
              data: {
                reportData: result.data,
                humeModelUsed: "hume-1.0",
              },
            });
          } else {
            // Create a new sentiment report
            const report = await prisma.sentimentReport.create({
              data: {
                userInteractionSessionId: session.id,
                reportData: result.data,
                humeModelUsed: "hume-1.0",
              },
            });
            
            // Update the session with the report ID
            await prisma.userInteractionSession.update({
              where: { id: params.id },
              data: {
                sentimentReportId: report.id,
              },
            });
          }
          
          // Update the session status to COMPLETED
          const updatedSession = await prisma.userInteractionSession.update({
            where: { id: params.id },
            data: {
              status: 'COMPLETED',
              errorMessage: null,
            },
            include: {
              sentimentReport: true,
            },
          });
          
          return new Response(
            JSON.stringify(updatedSession),
            { status: 200, headers: { 'Content-Type': 'application/json' } }
          );
        } else {
          // Update the session with failed status and error message
          const updatedSession = await prisma.userInteractionSession.update({
            where: { id: params.id },
            data: {
              status: 'FAILED',
              errorMessage: result.error || "Failed to generate sentiment report",
            },
          });
          
          return new Response(
            JSON.stringify({ error: result.error || "Failed to generate sentiment report", session: updatedSession }),
            { status: 500, headers: { 'Content-Type': 'application/json' } }
          );
        }
      } catch (error) {
        // Update the session with failed status and error message
        const updatedSession = await prisma.userInteractionSession.update({
          where: { id: params.id },
          data: {
            status: 'FAILED',
            errorMessage: error instanceof Error ? error.message : "An unknown error occurred",
          },
        });
        
        return new Response(
          JSON.stringify({ error: error instanceof Error ? error.message : "An unknown error occurred", session: updatedSession }),
          { status: 500, headers: { 'Content-Type': 'application/json' } }
        );
      }
    } else {
      return new Response(
        JSON.stringify({ error: 'Invalid action' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }
  } catch (error) {
    console.error(`Error updating session ${params.id}:`, error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'An unknown error occurred' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}