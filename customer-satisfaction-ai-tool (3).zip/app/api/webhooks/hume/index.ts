import crypto from 'crypto';
import prisma from '@/lib/prisma';
import { verifyHumeWebhookSignature } from '@/services/aiService';
import { HUME_WEBHOOK_SECRET, TESTING_MODE } from '@/app/config';

/**
 * Webhook handler for Hume AI callbacks
 * 
 * Firebase Studio Testing:
 * 1. Set TESTING_MODE=true in environment variables to bypass signature verification
 * 2. Use curl or the webhook-simulator.js script to send test payloads
 * 3. For production, always disable TESTING_MODE and use proper signature verification
 */
export async function POST(request: Request) {
  try {
    // Get the signature and timestamp from the headers
    const signature = request.headers.get('x-hume-signature');
    const timestamp = request.headers.get('x-hume-timestamp');
    
    // Skip signature verification in testing mode
    if (!TESTING_MODE && (!signature || !timestamp)) {
      console.error('Missing webhook signature or timestamp');
      return new Response(JSON.stringify({ error: 'Missing signature or timestamp' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    
    // Get the request body as text for signature verification
    const bodyText = await request.text();
    const parsedBody = JSON.parse(bodyText);
    
    // Verify the webhook signature (skip in testing mode)
    if (!TESTING_MODE) {
      if (!HUME_WEBHOOK_SECRET) {
        console.error('Hume webhook secret is not configured');
        return new Response(JSON.stringify({ error: 'Webhook secret not configured' }), {
          status: 500,
          headers: { 'Content-Type': 'application/json' }
        });
      }
      
      const isValid = verifyHumeWebhookSignature(
        signature || '',
        timestamp || '',
        bodyText,
        HUME_WEBHOOK_SECRET
      );
      
      if (!isValid) {
        console.error('Invalid webhook signature');
        return new Response(JSON.stringify({ error: 'Invalid signature' }), {
          status: 401,
          headers: { 'Content-Type': 'application/json' }
        });
      }
    } else {
      console.log('TESTING MODE: Signature verification bypassed');
    }

    // Parse the webhook payload
    const { sessionId, reportData } = parsedBody;

    if (!sessionId || !reportData) {
      return new Response(JSON.stringify({ error: 'Invalid webhook payload' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Find the session by Hume session ID
    const session = await prisma.userInteractionSession.findFirst({
      where: { humeSessionId: sessionId },
    });

    if (!session) {
      console.error(`Session not found for Hume sessionId: ${sessionId}`);
      return new Response(JSON.stringify({ error: 'Session not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Check for idempotency - don't process if already completed
    if (session.status === 'COMPLETED') {
      console.log(`Session ${session.id} already processed, skipping`);
      return new Response(JSON.stringify({ status: 'already_processed' }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Create the sentiment report in the database
    const report = await prisma.sentimentReport.create({
      data: {
        userInteractionSessionId: session.id,
        reportData: reportData,
        humeModelUsed: "hume-1.0",
      },
    });

    // Update the session status to COMPLETED
    await prisma.userInteractionSession.update({
      where: { id: session.id },
      data: {
        status: 'COMPLETED',
        sentimentReportId: report.id,
      },
    });

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Error processing Hume webhook:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Internal server error' 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}