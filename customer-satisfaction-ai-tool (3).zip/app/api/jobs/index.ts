import prisma from '@/lib/prisma';
import { generateQuestionnaire } from '@/services/aiService';

export async function GET(request: Request) {
  try {
    const jobs = await prisma.platformAnalysisJob.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        questionnaireBlueprint: true,
      },
    });

    return new Response(JSON.stringify(jobs), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Error fetching jobs:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Internal server error' 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function POST(request: Request) {
  try {
    const { platformUrl, aiProvider = 'gemini' } = await request.json();

    if (!platformUrl) {
      return new Response(JSON.stringify({ error: 'Platform URL is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Create a new job with ANALYZING status
    const job = await prisma.platformAnalysisJob.create({
      data: {
        platformUrl,
        status: 'ANALYZING',
        aiProviderUsed: aiProvider,
      },
    });

    // Start the questionnaire generation process
    try {
      // Generate the questionnaire
      const result = await generateQuestionnaire(platformUrl, aiProvider);
      
      if (result.success && result.data) {
        // Create the questionnaire blueprint
        const questionnaire = await prisma.questionnaireBlueprint.create({
          data: {
            platformAnalysisJobId: job.id,
            questionnaireText: result.data,
            geminiModelUsed: aiProvider === 'gemini' ? 'gemini-pro' : 
                             aiProvider === 'openai' ? 'gpt-4o' : 
                             'llama3-8b-8192',
          },
        });
        
        // Update the job with the questionnaire ID and completed status
        const updatedJob = await prisma.platformAnalysisJob.update({
          where: { id: job.id },
          data: {
            status: 'COMPLETED',
            questionnaireBlueprintId: questionnaire.id,
          },
          include: {
            questionnaireBlueprint: true,
          },
        });
        
        return new Response(JSON.stringify(updatedJob), {
          status: 201,
          headers: { 'Content-Type': 'application/json' }
        });
      } else {
        // Update the job with failed status and error message
        const updatedJob = await prisma.platformAnalysisJob.update({
          where: { id: job.id },
          data: {
            status: 'FAILED',
            errorMessage: result.error || 'Failed to generate questionnaire',
          },
        });
        
        return new Response(JSON.stringify({
          error: result.error || 'Failed to generate questionnaire',
          job: updatedJob,
        }), {
          status: 500,
          headers: { 'Content-Type': 'application/json' }
        });
      }
    } catch (error) {
      // Update the job with failed status and error message
      const updatedJob = await prisma.platformAnalysisJob.update({
        where: { id: job.id },
        data: {
          status: 'FAILED',
          errorMessage: error instanceof Error ? error.message : 'An unknown error occurred',
        },
      });
      
      return new Response(JSON.stringify({
        error: error instanceof Error ? error.message : 'An unknown error occurred',
        job: updatedJob,
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
  } catch (error) {
    console.error('Error creating job:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Internal server error' 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}