import prisma from '@/lib/prisma';
import { generateQuestionnaire } from '@/services/aiService';

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const job = await prisma.platformAnalysisJob.findUnique({
      where: { id: params.id },
      include: {
        questionnaireBlueprint: true,
      },
    });
    
    if (!job) {
      return new Response(
        JSON.stringify({ error: 'Job not found' }),
        { status: 404, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    return new Response(
      JSON.stringify(job),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error(`Error fetching job ${params.id}:`, error);
    return new Response(
      JSON.stringify({ error: 'Failed to fetch job' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    // Check if job exists
    const job = await prisma.platformAnalysisJob.findUnique({
      where: { id: params.id },
    });
    
    if (!job) {
      return new Response(
        JSON.stringify({ error: 'Job not found' }),
        { status: 404, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    // Delete the job (this will cascade delete the questionnaire blueprint due to our schema)
    await prisma.platformAnalysisJob.delete({
      where: { id: params.id },
    });
    
    return new Response(
      JSON.stringify({ success: true }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error(`Error deleting job ${params.id}:`, error);
    return new Response(
      JSON.stringify({ error: 'Failed to delete job' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const { action } = body;
    
    if (action === 'retry') {
      // Get the job
      const job = await prisma.platformAnalysisJob.findUnique({
        where: { id: params.id },
      });
      
      if (!job) {
        return new Response(
          JSON.stringify({ error: 'Job not found' }),
          { status: 404, headers: { 'Content-Type': 'application/json' } }
        );
      }
      
      // Update job status to analyzing
      await prisma.platformAnalysisJob.update({
        where: { id: params.id },
        data: {
          status: 'ANALYZING',
          errorMessage: null,
        },
      });
      
      // Generate the questionnaire using AI
      const result = await generateQuestionnaire(job.platformUrl);
      
      if (result.success && result.data) {
        // If there's an existing questionnaire, update it
        if (job.questionnaireBlueprintId) {
          await prisma.questionnaireBlueprint.update({
            where: { id: job.questionnaireBlueprintId },
            data: {
              questionnaireText: result.data,
              geminiModelUsed: "gemini-pro",
            },
          });
          
          // Update the job status
          const updatedJob = await prisma.platformAnalysisJob.update({
            where: { id: params.id },
            data: {
              status: 'COMPLETED',
              errorMessage: null,
            },
            include: {
              questionnaireBlueprint: true,
            },
          });
          
          return new Response(
            JSON.stringify(updatedJob),
            { status: 200, headers: { 'Content-Type': 'application/json' } }
          );
        } else {
          // Create a new questionnaire blueprint
          const questionnaire = await prisma.questionnaireBlueprint.create({
            data: {
              platformAnalysisJobId: job.id,
              questionnaireText: result.data,
              geminiModelUsed: "gemini-pro",
            },
          });
          
          // Update the job with the questionnaire ID and completed status
          const updatedJob = await prisma.platformAnalysisJob.update({
            where: { id: params.id },
            data: {
              questionnaireBlueprintId: questionnaire.id,
              status: 'COMPLETED',
              errorMessage: null,
            },
            include: {
              questionnaireBlueprint: true,
            },
          });
          
          return new Response(
            JSON.stringify(updatedJob),
            { status: 200, headers: { 'Content-Type': 'application/json' } }
          );
        }
      } else {
        // Update the job with failed status and error message
        const updatedJob = await prisma.platformAnalysisJob.update({
          where: { id: params.id },
          data: {
            status: 'FAILED',
            errorMessage: result.error || "Failed to generate questionnaire",
          },
        });
        
        return new Response(
          JSON.stringify({ error: result.error || "Failed to generate questionnaire", job: updatedJob }),
          { status: 500, headers: { 'Content-Type': 'application/json' } }
        );
      }
    } else {
      return new Response(
        JSON.stringify({ error: 'Invalid action' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }
  } catch (error) {
    console.error(`Error updating job ${params.id}:`, error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'An unknown error occurred' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}