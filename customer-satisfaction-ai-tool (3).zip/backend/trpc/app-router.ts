import { createTRPCRouter } from "./create-context";
import { hiProcedure } from "./routes/example/hi/route";
import { getJobsProcedure, createJobProcedure, getJobByIdProcedure } from "./routes/jobs/route";
import { getQuestionnaireProcedure } from "./routes/questionnaires/route";
import { getSessionsProcedure, createSessionProcedure, getSessionByIdProcedure } from "./routes/sessions/route";
import { getReportByIdProcedure } from "./routes/reports/route";

export const appRouter = createTRPCRouter({
  example: createTRPCRouter({
    hi: hiProcedure,
  }),
  jobs: createTRPCRouter({
    getJobs: getJobsProcedure,
    createJob: createJobProcedure,
    getJobById: getJobByIdProcedure,
  }),
  questionnaires: createTRPCRouter({
    getQuestionnaire: getQuestionnaireProcedure,
  }),
  sessions: createTRPCRouter({
    getSessions: getSessionsProcedure,
    createSession: createSessionProcedure,
    getSessionById: getSessionByIdProcedure,
  }),
  reports: createTRPCRouter({
    getReportById: getReportByIdProcedure,
  }),
});

export type AppRouter = typeof appRouter;