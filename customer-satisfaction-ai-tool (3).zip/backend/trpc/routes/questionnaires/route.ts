import { z } from "zod";
import { publicProcedure } from "../../create-context";

// Mock data for questionnaires
const mockQuestionnaires = [
  {
    id: "questionnaire-1",
    title: "Customer Satisfaction Survey",
    description: "Help us understand your experience with our platform",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    questions: [
      {
        id: "q1",
        text: "How would you rate your overall experience?",
        type: "rating",
        options: ["1", "2", "3", "4", "5"],
        required: true,
      },
      {
        id: "q2",
        text: "What features do you like the most?",
        type: "text",
        options: [],
        required: false,
      },
      {
        id: "q3",
        text: "Would you recommend our platform to others?",
        type: "boolean",
        options: ["Yes", "No"],
        required: true,
      },
    ],
  },
  {
    id: "questionnaire-2",
    title: "User Experience Survey",
    description: "Help us improve our user interface",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    questions: [
      {
        id: "q1",
        text: "How easy was it to navigate our platform?",
        type: "rating",
        options: ["1", "2", "3", "4", "5"],
        required: true,
      },
      {
        id: "q2",
        text: "What aspects of the UI could be improved?",
        type: "text",
        options: [],
        required: false,
      },
    ],
  },
];

// Get questionnaire by ID
export const getQuestionnaireProcedure = publicProcedure
  .input(z.object({ id: z.string() }))
  .query(({ input }) => {
    const questionnaire = mockQuestionnaires.find((q) => q.id === input.id);
    if (!questionnaire) {
      throw new Error(`Questionnaire with ID ${input.id} not found`);
    }
    return questionnaire;
  });