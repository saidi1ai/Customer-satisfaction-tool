import { z } from 'zod';
import { publicProcedure, router } from '../../app-router';
import prisma from '@/lib/prisma';
import { generateQuestionnaire } from '@/services/aiService';

export const jobsRouter = router({
  getJobs: publicProcedure.query(async () => {
    return await prisma.platformAnalysisJob.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        questionnaireBlueprint: true,
      },
    });
  }),

  getJob: publicProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ input }) => {
      const job = await prisma.platformAnalysisJob.findUnique({
        where: { id: input.id },
        include: {
          questionnaireBlueprint: true,
        },
      });

      if (!job) {
        throw new Error('Job not found');
      }

      return job;
    }),

  createJob: publicProcedure
    .input(
      z.object({
        platformUrl: z.string().url(),
        aiProvider: z.enum(['gemini', 'openai', 'groq']).default('gemini'),
      })
    )
    .mutation(async ({ input }) => {
      // Create a new job with ANALYZING status
      const job = await prisma.platformAnalysisJob.create({
        data: {
          platformUrl: input.platformUrl,
          status: 'ANALYZING',
          aiProviderUsed: input.aiProvider,
        },
      });

      try {
        // Generate the questionnaire
        const result = await generateQuestionnaire(input.platformUrl, input.aiProvider);
        
        if (result.success && result.data) {
          // Create the questionnaire blueprint
          const questionnaire = await prisma.questionnaireBlueprint.create({
            data: {
              platformAnalysisJobId: job.id,
              questionnaireText: result.data,
              geminiModelUsed: input.aiProvider === 'gemini' ? 'gemini-pro' : 
                               input.aiProvider === 'openai' ? 'gpt-4o' : 
                               'llama3-8b-8192',
            },
          });
          
          // Update the job with the questionnaire ID and completed status
          const updatedJob = await prisma.platformAnalysisJob.update({
            where: { id: job.id },
            data: {
              status: 'COMPLETED',
              questionnaireBlueprintId: questionnaire.id,
            },
            include: {
              questionnaireBlueprint: true,
            },
          });
          
          return updatedJob;
        } else {
          // Update the job with failed status and error message
          const updatedJob = await prisma.platformAnalysisJob.update({
            where: { id: job.id },
            data: {
              status: 'FAILED',
              errorMessage: result.error || 'Failed to generate questionnaire',
            },
          });
          
          throw new Error(result.error || 'Failed to generate questionnaire');
        }
      } catch (error) {
        // Update the job with failed status and error message
        await prisma.platformAnalysisJob.update({
          where: { id: job.id },
          data: {
            status: 'FAILED',
            errorMessage: error instanceof Error ? error.message : 'An unknown error occurred',
          },
        });
        
        throw error;
      }
    }),
});