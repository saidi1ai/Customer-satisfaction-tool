import { z } from "zod";
import { publicProcedure } from "../../create-context";

// Mock data for sentiment reports
const mockReports = [
  {
    id: "report-1",
    sessionId: "session-1",
    createdAt: new Date().toISOString(),
    overallSentiment: 0.8,
    sentimentBreakdown: {
      positive: 0.85,
      neutral: 0.1,
      negative: 0.05,
    },
    keyInsights: [
      "User is highly satisfied with the platform",
      "Dashboard and analytics features are particularly appreciated",
      "User is likely to recommend the platform to others",
    ],
    recommendations: [
      "Consider expanding analytics features",
      "Highlight dashboard in marketing materials",
      "Implement a referral program",
    ],
  },
  {
    id: "report-2",
    sessionId: "session-2",
    createdAt: new Date().toISOString(),
    overallSentiment: 0.4,
    sentimentBreakdown: {
      positive: 0.3,
      neutral: 0.5,
      negative: 0.2,
    },
    keyInsights: [
      "User finds navigation challenging",
      "Overall experience is average",
      "UI improvements are needed",
    ],
    recommendations: [
      "Conduct usability testing",
      "Simplify navigation structure",
      "Consider UI redesign for key features",
    ],
  },
];

// Get report by ID
export const getReportByIdProcedure = publicProcedure
  .input(z.object({ id: z.string() }))
  .query(({ input }) => {
    const report = mockReports.find((r) => r.id === input.id);
    if (!report) {
      throw new Error(`Report with ID ${input.id} not found`);
    }
    return report;
  });