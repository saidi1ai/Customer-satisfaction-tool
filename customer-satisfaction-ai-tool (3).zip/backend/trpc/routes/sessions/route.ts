import { z } from "zod";
import { publicProcedure } from "../../create-context";

// Mock data for sessions
const mockSessions = [
  {
    id: "session-1",
    questionnaireId: "questionnaire-1",
    userId: "user-1",
    startedAt: new Date().toISOString(),
    completedAt: new Date().toISOString(),
    responses: [
      { questionId: "q1", answer: "5" },
      { questionId: "q2", answer: "I love the dashboard and analytics features." },
      { questionId: "q3", answer: "Yes" },
    ],
    sentimentReportId: "report-1",
  },
  {
    id: "session-2",
    questionnaireId: "questionnaire-2",
    userId: "user-2",
    startedAt: new Date().toISOString(),
    completedAt: new Date().toISOString(),
    responses: [
      { questionId: "q1", answer: "3" },
      { questionId: "q2", answer: "The navigation could be more intuitive." },
    ],
    sentimentReportId: "report-2",
  },
];

// Get all sessions
export const getSessionsProcedure = publicProcedure.query(() => {
  return mockSessions;
});

// Get session by ID
export const getSessionByIdProcedure = publicProcedure
  .input(z.object({ id: z.string() }))
  .query(({ input }) => {
    const session = mockSessions.find((s) => s.id === input.id);
    if (!session) {
      throw new Error(`Session with ID ${input.id} not found`);
    }
    return session;
  });

// Create a new session
export const createSessionProcedure = publicProcedure
  .input(
    z.object({
      questionnaireId: z.string(),
      userId: z.string().optional(),
      responses: z.array(
        z.object({
          questionId: z.string(),
          answer: z.string(),
        })
      ),
    })
  )
  .mutation(({ input }) => {
    const newSession = {
      id: `session-${Date.now()}`,
      questionnaireId: input.questionnaireId,
      userId: input.userId || `anonymous-${Date.now()}`,
      startedAt: new Date().toISOString(),
      completedAt: new Date().toISOString(),
      responses: input.responses,
      sentimentReportId: `report-${Date.now()}`, // Generate a placeholder ID instead of null
    };
    
    // In a real app, you would save this to a database
    mockSessions.push(newSession);
    
    return newSession;
  });