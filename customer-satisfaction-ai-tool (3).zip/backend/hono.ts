import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { fetchRequestHandler } from '@trpc/server/adapters/fetch';
import { appRouter } from './trpc/app-router';
import { createContext } from './trpc/create-context';
import http from 'http';

const app = new Hono();

// Enable CORS
app.use('/*', cors());

// Health check endpoint
app.get('/', (c) => c.text('API is running'));

// tRPC endpoint
app.all('/api/trpc/*', async (c) => {
  return await fetchRequestHandler({
    endpoint: '/api/trpc',
    req: c.req.raw,
    router: appRouter,
    createContext,
    onError({ error }) {
      console.error('Error:', error);
    },
    batching: {
      enabled: true,
    },
  });
});

// Start the server if this file is run directly
if (process.env.NODE_ENV !== 'production') {
  const port = process.env.PORT || 3000;
  console.log(`Server is running on port ${port}`);
  
  // Create HTTP server without dynamic imports
  const server = http.createServer((req, res) => {
    // Convert Node.js request to Fetch API Request
    const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    
    const headers = new Headers();
    Object.entries(req.headers).forEach(([key, value]: [string, string | string[] | undefined]) => {
      if (value) headers.set(key, Array.isArray(value) ? value.join(', ') : value);
    });
    
    // Create a Request object that Hono can handle
    const request = new Request(url.toString(), {
      method: req.method,
      headers: headers,
    });
    
    // Process the request with Hono and handle the response
    const processResponse = async () => {
      try {
        const response = await app.fetch(request);
        
        // Set status code
        res.statusCode = response.status;
        
        // Set headers
        response.headers.forEach((value: string, key: string) => {
          res.setHeader(key, value);
        });
        
        // Send response body
        const buffer = await response.arrayBuffer();
        res.end(Buffer.from(buffer));
      } catch (err: unknown) {
        console.error('Error handling request:', err);
        res.statusCode = 500;
        res.end('Internal Server Error');
      }
    };
    
    processResponse();
  });
  
  server.listen(Number(port));
}

export default app;