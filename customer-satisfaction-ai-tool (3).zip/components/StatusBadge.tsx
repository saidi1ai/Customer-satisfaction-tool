import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Colors from '@/constants/colors';
import { JobStatus, SessionStatus } from '@/types';

interface StatusBadgeProps {
  status: JobStatus | SessionStatus;
  size?: 'small' | 'medium' | 'large';
}

export default function StatusBadge({ status, size = 'medium' }: StatusBadgeProps) {
  const getStatusColor = () => {
    switch (status) {
      case JobStatus.PENDING:
      case SessionStatus.PENDING:
        return {
          bg: Colors.warningLight,
          text: Colors.warningText,
        };
      case JobStatus.ANALYZING:
      case SessionStatus.IN_PROGRESS:
        return {
          bg: Colors.infoLight,
          text: Colors.infoText,
        };
      case JobStatus.COMPLETED:
      case SessionStatus.COMPLETED:
        return {
          bg: Colors.successLight,
          text: Colors.successText,
        };
      case JobStatus.FAILED:
      case SessionStatus.FAILED:
        return {
          bg: Colors.errorLight,
          text: Colors.errorText,
        };
      default:
        return {
          bg: Colors.backgroundSecondary,
          text: Colors.textSecondary,
        };
    }
  };

  const getSizeStyle = () => {
    switch (size) {
      case 'small':
        return {
          container: styles.smallContainer,
          text: styles.smallText,
        };
      case 'large':
        return {
          container: styles.largeContainer,
          text: styles.largeText,
        };
      default:
        return {
          container: styles.mediumContainer,
          text: styles.mediumText,
        };
    }
  };

  const colors = getStatusColor();
  const sizeStyles = getSizeStyle();

  return (
    <View 
      style={[
        styles.container, 
        sizeStyles.container, 
        { backgroundColor: colors.bg }
      ]}
    >
      <Text 
        style={[
          styles.text, 
          sizeStyles.text, 
          { color: colors.text }
        ]}
      >
        {status}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 16,
    alignSelf: 'flex-start',
  },
  text: {
    fontWeight: '600',
  },
  // Sizes
  smallContainer: {
    paddingVertical: 2,
    paddingHorizontal: 8,
  },
  smallText: {
    fontSize: 12,
  },
  mediumContainer: {
    paddingVertical: 4,
    paddingHorizontal: 12,
  },
  mediumText: {
    fontSize: 14,
  },
  largeContainer: {
    paddingVertical: 6,
    paddingHorizontal: 16,
  },
  largeText: {
    fontSize: 16,
  },
});