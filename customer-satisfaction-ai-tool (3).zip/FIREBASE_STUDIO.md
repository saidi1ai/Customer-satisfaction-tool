# Firebase Studio Setup Guide

This document provides detailed instructions for setting up and running the CSAT AI Tool in Firebase Studio (formerly Project IDX).

## Environment Setup

Firebase Studio provides a secure way to manage environment variables through its Secret Manager integration.

### Setting Up Environment Variables

1. Open your project in Firebase Studio
2. Click on the "Settings" icon in the sidebar
3. Navigate to "Secrets" or "Environment Variables" section
4. Add each of the following environment variables:

| Variable Name | Description | Example |
|---------------|-------------|---------|
| DATABASE_URL | Supabase PostgreSQL connection string | postgresql://postgres:password@db.example.supabase.co:5432/postgres |
| SUPABASE_URL | Your Supabase project URL | https://example.supabase.co |
| NEXT_PUBLIC_SUPABASE_URL | Same as SUPABASE_URL (for client-side use) | https://example.supabase.co |
| SUPABASE_SERVICE_ROLE_KEY | Supabase service role key for admin access | eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9... |
| NEXT_PUBLIC_SUPABASE_ANON_KEY | Supabase anonymous key for client-side access | eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9... |
| GEMINI_API_KEY | Google Gemini API key | AIzaSyA1B2C3D4E5F6G7H8I9J0K... |
| HUME_API_KEY | Hume AI API key | hume_123456789abcdef... |
| HUME_WEBHOOK_SECRET | Secret for verifying Hume webhook signatures | whsec_123456789abcdef... |
| TESTING_MODE | Enable testing mode (set to "false" in production) | true |

### Accessing Environment Variables

Firebase Studio automatically makes these environment variables available to your application through `process.env`. Our application's `app/config.ts` file is already configured to use these variables.

## Running the Application

### Initial Setup

1. Open a terminal in Firebase Studio by clicking on the "Terminal" tab
2. Install dependencies:
```bash
npm install
```

3. Generate Prisma client and run migrations:
```bash
npx prisma generate
npx prisma migrate dev
```

### Starting the Development Server

1. Start the Expo development server:
```bash
npx expo start --web
```

2. Firebase Studio will detect the running web server and provide a preview URL. Click on the preview URL or use the "Web Preview" button to open the application.

## Testing Webhook Functionality

Since Firebase Studio runs in a cloud environment that doesn't expose local servers to the internet, testing webhooks requires special handling.

### Option 1: Webhook Simulation

The project includes a webhook simulation script that can be used to test the webhook handler logic:

1. Open a terminal and run:
```bash
node scripts/webhook-simulator.js
```

2. This script sends a simulated Hume webhook payload to your local webhook endpoint, allowing you to test the webhook handler's logic without requiring an actual callback from Hume AI.

3. The script automatically sets `TESTING_MODE=true` to bypass signature verification during testing.

### Option 2: Tunneling (Limited Support)

If Firebase Studio allows installing and running tunneling tools:

1. Install ngrok (if allowed):
```bash
npm install -g ngrok
```

2. In a separate terminal, expose your local server:
```bash
ngrok http 8081
```

3. Configure the generated ngrok URL (e.g., https://a1b2c3d4.ngrok.io/api/webhooks/hume) in your Hume AI dashboard as the webhook URL.

4. Note: This approach may not work in all Firebase Studio environments due to network restrictions.

### Option 3: Deployment Testing

For comprehensive webhook testing:

1. Deploy your application to a public environment (see README.md for deployment instructions)
2. Configure the deployed webhook URL in your Hume AI dashboard
3. Test with real Hume AI callbacks

## Debugging

### Console Logs

Firebase Studio provides access to console logs in the terminal where you run the Expo server. Watch this terminal for any errors or debugging information.

### Browser Developer Tools

When using the web preview, you can access browser developer tools to debug client-side issues:

1. Right-click in the web preview
2. Select "Inspect" or "Inspect Element"
3. Navigate to the Console, Network, or Application tabs as needed

### API Route Testing

To test API routes directly:

1. Open a new terminal
2. Use curl to send requests to your local API endpoints:
```bash
curl http://localhost:8081/api/jobs
```

## Using Firebase Studio AI Assistance

Firebase Studio includes AI assistance features that can help with development:

1. Select code you want help with
2. Right-click and select "Explain Code" or "Suggest Improvements"
3. Use the AI chat interface to ask questions about your code

## Common Issues and Solutions

### Database Connection Issues

If you encounter database connection errors:

1. Verify your DATABASE_URL is correctly set in environment variables
2. Check if your IP address is allowed in Supabase's database settings
3. Try running `npx prisma db push` to ensure schema changes are applied

### Webhook Testing Failures

If webhook simulation fails:

1. Ensure TESTING_MODE is set to "true" during development
2. Check the webhook handler logs for specific error messages
3. Verify the webhook payload structure in the simulation script matches what Hume AI sends

### API Route 404 Errors

If API routes return 404 errors:

1. Ensure you're using the correct URL format (e.g., `/api/jobs` not `/jobs`)
2. Check that the Expo server is running with API routes enabled
3. Verify the route handler file exists in the correct location