import { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } from '@google/generative-ai';
import { GEMINI_API_KEY, OPENAI_API_KEY, GROQ_API_KEY, HUME_API_KEY } from '@/app/config';
// Use expo-crypto instead of Node's crypto
import * as ExpoCrypto from 'expo-crypto';

// Types for AI service responses
export interface QuestionnaireSummary {
  title: string;
  description: string;
  questions: Array<{
    id: string;
    text: string;
    type: 'multiple_choice' | 'open_ended' | 'rating';
    options?: string[];
  }>;
}

export interface SentimentReport {
  overallSentiment: number;
  keyInsights: string[];
  emotionBreakdown: {
    joy: number;
    anger: number;
    sadness: number;
    fear: number;
    surprise: number;
    disgust: number;
  };
  recommendations: string[];
  transcriptHighlights: Array<{
    text: string;
    sentiment: number;
    emotion: string;
  }>;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

// System prompts
const QUESTIONNAIRE_SYSTEM_PROMPT = `
You are the Questionnaire Architect, an expert in creating effective customer satisfaction surveys.
Your task is to analyze a platform and generate a tailored questionnaire that will help gather meaningful feedback.

Guidelines:
1. Create a mix of multiple-choice, rating (1-5), and open-ended questions
2. Focus on usability, feature satisfaction, and overall experience
3. Keep questions clear, concise, and unbiased
4. Include 8-12 questions total
5. Structure the response as a JSON object with:
   - title: A concise title for the questionnaire
   - description: A brief introduction explaining the purpose
   - questions: An array of question objects with:
     - id: A unique string identifier
     - text: The question text
     - type: "multiple_choice", "rating", or "open_ended"
     - options: An array of possible answers (for multiple_choice only)

Example format:
{
  "title": "Platform Satisfaction Survey",
  "description": "Help us improve by sharing your experience with our platform",
  "questions": [
    {
      "id": "q1",
      "text": "How easy was it to navigate the platform?",
      "type": "rating"
    },
    {
      "id": "q2",
      "text": "Which feature do you find most valuable?",
      "type": "multiple_choice",
      "options": ["Feature A", "Feature B", "Feature C", "Other"]
    }
  ]
}
`;

const SENTIMENT_SYSTEM_PROMPT = `
You are the Sentiment Understanding Navigator (SUN), an empathetic AI designed to conduct user interviews.
Your goal is to understand the user's experience with a platform based on a questionnaire.

Guidelines:
1. Begin by introducing yourself and explaining the purpose of the interview
2. Ask questions from the provided questionnaire, but feel free to ask follow-up questions
3. Show empathy and active listening in your responses
4. Encourage detailed feedback without leading the user
5. Adapt to the user's tone and concerns
6. Conclude by thanking them for their time and feedback

The interview should feel conversational and natural, not like a rigid survey.
`;

/**
 * Generates a questionnaire for a specific platform using the selected AI provider
 * @param platformUrl The URL of the platform to analyze
 * @param aiProvider The AI provider to use (gemini, openai, groq)
 * @returns A promise that resolves to an ApiResponse containing a questionnaire or error
 */
export async function generateQuestionnaire(
  platformUrl: string, 
  aiProvider: string = 'gemini'
): Promise<ApiResponse<string>> {
  try {
    // Prepare the prompt for questionnaire generation
    const prompt = `
      Please analyze the following platform and create a customer satisfaction questionnaire:
      Platform URL: ${platformUrl}
      
      Generate a comprehensive questionnaire that will help gather meaningful feedback about this platform.
    `;

    // Generate content based on the selected AI provider
    switch (aiProvider.toLowerCase()) {
      case 'openai':
        return await generateWithOpenAI(prompt);
      case 'groq':
        return await generateWithGroq(prompt);
      case 'gemini':
      default:
        return await generateWithGemini(prompt);
    }
  } catch (error) {
    console.error(`Error generating questionnaire with ${aiProvider}:`, error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'An unknown error occurred'
    };
  }
}

/**
 * Generates a questionnaire using Google Gemini AI
 * @param prompt The prompt to send to Gemini
 * @returns A promise that resolves to an ApiResponse containing a questionnaire or error
 */
async function generateWithGemini(prompt: string): Promise<ApiResponse<string>> {
  // Check if API key is available
  if (!GEMINI_API_KEY) {
    console.error('Gemini API key is not configured');
    return {
      success: false,
      error: 'Gemini API key is not configured. Please contact your administrator.'
    };
  }

  try {
    // Initialize the Google Generative AI client
    const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
    
    // Configure the model with safety settings
    const model = genAI.getGenerativeModel({
      model: 'gemini-pro',
      safetySettings: [
        {
          category: HarmCategory.HARM_CATEGORY_HARASSMENT,
          threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
        },
        {
          category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
          threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
        },
      ],
    });

    // Generate content using Gemini
    const result = await model.generateContent({
      contents: [
        {
          role: 'user',
          parts: [
            { text: QUESTIONNAIRE_SYSTEM_PROMPT },
            { text: prompt }
          ]
        }
      ],
    });

    const response = result.response;
    const text = response.text();
    
    // Parse the JSON response
    try {
      // Validate that the response is valid JSON
      JSON.parse(text);
      
      // Return the raw text for storage
      return {
        success: true,
        data: text
      };
    } catch (parseError) {
      console.error('Failed to parse Gemini response as JSON:', parseError);
      return {
        success: false,
        error: 'Invalid response format from Gemini API. Please try again.'
      };
    }
  } catch (error) {
    console.error('Error generating questionnaire with Gemini:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'An unknown error occurred'
    };
  }
}

/**
 * Generates a questionnaire using OpenAI
 * @param prompt The prompt to send to OpenAI
 * @returns A promise that resolves to an ApiResponse containing a questionnaire or error
 */
async function generateWithOpenAI(prompt: string): Promise<ApiResponse<string>> {
  // Check if API key is available
  if (!OPENAI_API_KEY) {
    console.error('OpenAI API key is not configured');
    return {
      success: false,
      error: 'OpenAI API key is not configured. Please contact your administrator.'
    };
  }

  try {
    // For this implementation, we'll use a mock response since we can't directly import OpenAI in Expo
    // In a real implementation, you would use the OpenAI SDK
    console.log('Would call OpenAI with prompt:', prompt);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Mock response in the expected format
    const mockResponse = {
      "title": "Website User Experience Survey",
      "description": "Help us improve our platform by sharing your experience and feedback",
      "questions": [
        {
          "id": "q1",
          "text": "How easy was it to navigate our platform?",
          "type": "rating"
        },
        {
          "id": "q2",
          "text": "Which features did you find most useful?",
          "type": "multiple_choice",
          "options": ["Search functionality", "User dashboard", "Content organization", "Mobile responsiveness", "Other"]
        },
        {
          "id": "q3",
          "text": "How would you rate the overall design and visual appeal?",
          "type": "rating"
        },
        {
          "id": "q4",
          "text": "Did you encounter any difficulties while using our platform?",
          "type": "multiple_choice",
          "options": ["Yes", "No"]
        },
        {
          "id": "q5",
          "text": "If you encountered difficulties, please describe them:",
          "type": "open_ended"
        },
        {
          "id": "q6",
          "text": "How likely are you to recommend our platform to others?",
          "type": "rating"
        },
        {
          "id": "q7",
          "text": "What additional features would you like to see implemented?",
          "type": "open_ended"
        },
        {
          "id": "q8",
          "text": "How would you rate the loading speed of our platform?",
          "type": "rating"
        },
        {
          "id": "q9",
          "text": "What is your primary purpose for using our platform?",
          "type": "multiple_choice",
          "options": ["Research", "Shopping", "Entertainment", "Education", "Business", "Other"]
        },
        {
          "id": "q10",
          "text": "Any additional comments or suggestions for improvement?",
          "type": "open_ended"
        }
      ]
    };
    
    return {
      success: true,
      data: JSON.stringify(mockResponse)
    };
  } catch (error) {
    console.error('Error generating questionnaire with OpenAI:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'An unknown error occurred'
    };
  }
}

/**
 * Generates a questionnaire using Groq
 * @param prompt The prompt to send to Groq
 * @returns A promise that resolves to an ApiResponse containing a questionnaire or error
 */
async function generateWithGroq(prompt: string): Promise<ApiResponse<string>> {
  // Check if API key is available
  if (!GROQ_API_KEY) {
    console.error('Groq API key is not configured');
    return {
      success: false,
      error: 'Groq API key is not configured. Please contact your administrator.'
    };
  }

  try {
    // For this implementation, we'll use a mock response since we can't directly import Groq in Expo
    // In a real implementation, you would use the Groq SDK
    console.log('Would call Groq with prompt:', prompt);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock response in the expected format
    const mockResponse = {
      "title": "Platform User Satisfaction Survey",
      "description": "We value your feedback! Please help us improve by answering a few questions about your experience with our platform.",
      "questions": [
        {
          "id": "q1",
          "text": "How would you rate your overall experience with our platform?",
          "type": "rating"
        },
        {
          "id": "q2",
          "text": "How easy was it to find what you were looking for?",
          "type": "rating"
        },
        {
          "id": "q3",
          "text": "Which of the following best describes your primary reason for using our platform?",
          "type": "multiple_choice",
          "options": ["Information gathering", "Making a purchase", "Customer support", "Account management", "Other"]
        },
        {
          "id": "q4",
          "text": "How satisfied are you with the loading speed of our pages?",
          "type": "rating"
        },
        {
          "id": "q5",
          "text": "Did you experience any technical issues during your visit?",
          "type": "multiple_choice",
          "options": ["Yes", "No"]
        },
        {
          "id": "q6",
          "text": "If you experienced technical issues, please describe them:",
          "type": "open_ended"
        },
        {
          "id": "q7",
          "text": "How likely are you to return to our platform in the future?",
          "type": "rating"
        },
        {
          "id": "q8",
          "text": "What feature or aspect of our platform do you find most valuable?",
          "type": "open_ended"
        },
        {
          "id": "q9",
          "text": "What improvements would make you more likely to use our platform regularly?",
          "type": "open_ended"
        },
        {
          "id": "q10",
          "text": "How would you rate the visual design and layout of our platform?",
          "type": "rating"
        }
      ]
    };
    
    return {
      success: true,
      data: JSON.stringify(mockResponse)
    };
  } catch (error) {
    console.error('Error generating questionnaire with Groq:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'An unknown error occurred'
    };
  }
}

/**
 * Initiates a user sentiment analysis session with Hume AI
 * @param questionnaireId The ID of the questionnaire to use
 * @param userId The ID of the user participating in the session
 * @returns A promise that resolves to the session ID from Hume AI
 */
export async function initiateHumeSession(questionnaireId: string, userId: string): Promise<string> {
  try {
    // Check if API key is available
    if (!HUME_API_KEY) {
      throw new Error('Hume API key is not configured. Please contact your administrator.');
    }

    // In a real implementation, we would fetch the questionnaire from the database
    // For now, we'll simulate this step
    const questionnaire = {
      id: questionnaireId,
      title: "Platform Satisfaction Survey",
      description: "Help us improve by sharing your experience with our platform",
      questions: [
        {
          id: "q1",
          text: "How easy was it to navigate the platform?",
          type: "rating"
        },
        {
          id: "q2",
          text: "Which feature do you find most valuable?",
          type: "multiple_choice",
          options: ["Feature A", "Feature B", "Feature C", "Other"]
        }
      ]
    };

    // Prepare the context for Hume AI based on the questionnaire
    const context = {
      questionnaire: questionnaire,
      systemPrompt: SENTIMENT_SYSTEM_PROMPT,
      userId: userId
    };

    // In a real implementation, this would make an API call to Hume AI
    // For now, we'll simulate the response
    console.log('Initiating Hume session with context:', context);
    
    // Generate a mock session ID using expo-crypto instead of Node's crypto
    const randomBytes = await ExpoCrypto.getRandomBytesAsync(4);
    const randomHex = Array.from(randomBytes)
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
    
    const humeSessionId = `hume-${Date.now()}-${randomHex}`;
    
    // In a real implementation, this would be the response from Hume AI
    return humeSessionId;
  } catch (error) {
    console.error('Error initiating Hume session:', error);
    throw error;
  }
}

/**
 * Generates a sentiment report based on questionnaire responses
 * @param questionnaireText The text of the questionnaire
 * @param responses The user's responses to the questionnaire
 * @returns A promise that resolves to an ApiResponse containing a sentiment report or error
 */
export async function generateSentimentReport(
  questionnaireText: string, 
  responses: Record<string, string>
): Promise<ApiResponse<any>> {
  try {
    // Check if API key is available
    if (!HUME_API_KEY) {
      console.error('Hume API key is not configured');
      return {
        success: false,
        error: 'Hume API key is not configured. Please contact your administrator.'
      };
    }

    // In a real implementation, this would make an API call to Hume AI
    // For now, we'll simulate the response
    console.log('Generating sentiment report for questionnaire:', questionnaireText);
    console.log('User responses:', responses);
    
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Generate a mock sentiment report
    const mockReport = {
      overallSentiment: Math.random() * 0.5 + 0.5, // Random value between 0.5 and 1.0
      keyInsights: [
        "Users appreciate the intuitive navigation",
        "The search functionality needs improvement",
        "Mobile responsiveness is highly valued",
        "Documentation could be more comprehensive"
      ],
      emotionBreakdown: {
        joy: Math.random() * 0.6 + 0.2,
        anger: Math.random() * 0.2,
        sadness: Math.random() * 0.2,
        fear: Math.random() * 0.1,
        surprise: Math.random() * 0.3,
        disgust: Math.random() * 0.1
      },
      recommendations: [
        "Enhance search functionality with filters",
        "Improve mobile responsiveness for complex features",
        "Expand documentation with more examples",
        "Consider adding user onboarding tutorials"
      ],
      transcriptHighlights: [
        {
          text: "I really love how easy it is to navigate the platform",
          sentiment: 0.9,
          emotion: "joy"
        },
        {
          text: "The search feature doesn't always find what I'm looking for",
          sentiment: 0.3,
          emotion: "frustration"
        },
        {
          text: "It works great on my phone, which is important for me",
          sentiment: 0.8,
          emotion: "satisfaction"
        }
      ],
      sentimentReport: `# Sentiment Analysis Report

## Overall Sentiment: ${Math.round((Math.random() * 0.5 + 0.5) * 100)}%

## Key Insights
* Users appreciate the intuitive navigation and clean interface
* The search functionality needs improvement in accuracy and speed
* Mobile responsiveness is highly valued by frequent users
* Documentation could be more comprehensive with additional examples

## Emotional Response Breakdown
* Satisfaction: 68%
* Frustration: 15%
* Neutral: 17%

## User Pain Points
1. Search functionality doesn't always return relevant results
2. Documentation lacks detailed examples for complex features
3. Some features are difficult to discover without guidance
4. Performance issues on older devices

## Positive Highlights
1. Clean and intuitive user interface
2. Excellent mobile responsiveness
3. Regular updates and improvements
4. Helpful customer support

## Recommendations
1. Enhance search functionality with better filters and relevance algorithms
2. Expand documentation with more practical examples and use cases
3. Consider implementing an onboarding tutorial for new users
4. Optimize performance for a wider range of devices
5. Add more customization options for power users

## Conclusion
The platform generally receives positive feedback, with users particularly appreciating the intuitive design and mobile experience. Focusing improvements on search functionality and documentation would address the main pain points identified in this analysis. The overall sentiment indicates users are satisfied but see room for specific improvements.`
    };
    
    return {
      success: true,
      data: mockReport
    };
  } catch (error) {
    console.error('Error generating sentiment report:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'An unknown error occurred'
    };
  }
}

/**
 * Verifies a webhook signature from Hume AI
 * @param signature The signature from the request headers
 * @param timestamp The timestamp from the request headers
 * @param body The request body as a string
 * @param secret The shared secret for verification
 * @returns A boolean indicating whether the signature is valid
 */
export function verifyHumeWebhookSignature(
  signature: string | null,
  timestamp: string | null,
  body: string,
  secret: string
): boolean {
  if (!signature || !timestamp || !secret) {
    return false;
  }

  try {
    // Create the expected signature using expo-crypto instead of Node's crypto
    const encoder = new TextEncoder();
    const data = encoder.encode(`${timestamp}.${body}`);
    const secretData = encoder.encode(secret);
    
    // In a real implementation, we would use HMAC-SHA256
    // For now, we'll use a simplified approach since expo-crypto doesn't directly support HMAC
    // This is a placeholder - in production, use a proper HMAC implementation
    console.log('Would verify signature with:', { signature, timestamp, bodyLength: body.length });
    
    // For demo purposes, always return true
    // In production, implement proper signature verification
    return true;
  } catch (error) {
    console.error('Error verifying webhook signature:', error);
    return false;
  }
}