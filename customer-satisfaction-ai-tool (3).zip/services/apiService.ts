import { Platform } from 'react-native';
import { API_BASE_URL } from '@/app/config';

// Mock data for testing without a backend
const MOCK_DATA = {
  jobs: [
    {
      id: 'job-1',
      platformUrl: 'https://example.com',
      status: 'COMPLETED',
      aiProviderUsed: 'gemini',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      questionnaireBlueprintId: 'questionnaire-1',
      questionnaireBlueprint: {
        id: 'questionnaire-1',
        platformAnalysisJobId: 'job-1',
        questionnaireText: JSON.stringify({
          title: 'Example.com User Experience Survey',
          description: 'Help us improve Example.com by sharing your feedback',
          questions: [
            {
              id: 'q1',
              text: 'How easy was it to navigate the website?',
              type: 'rating'
            },
            {
              id: 'q2',
              text: 'Which feature do you find most valuable?',
              type: 'multiple_choice',
              options: ['Search', 'Product listings', 'User reviews', 'Checkout process']
            }
          ]
        }),
        geminiModelUsed: 'gemini-pro',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    },
    {
      id: 'job-2',
      platformUrl: 'https://anotherexample.com',
      status: 'FAILED',
      aiProviderUsed: 'openai',
      errorMessage: 'Failed to analyze platform',
      createdAt: new Date(Date.now() - 86400000).toISOString(),
      updatedAt: new Date(Date.now() - 86400000).toISOString()
    }
  ],
  questionnaires: {
    'questionnaire-1': {
      id: 'questionnaire-1',
      platformAnalysisJobId: 'job-1',
      questionnaireText: JSON.stringify({
        title: 'Example.com User Experience Survey',
        description: 'Help us improve Example.com by sharing your feedback',
        questions: [
          {
            id: 'q1',
            text: 'How easy was it to navigate the website?',
            type: 'rating'
          },
          {
            id: 'q2',
            text: 'Which feature do you find most valuable?',
            type: 'multiple_choice',
            options: ['Search', 'Product listings', 'User reviews', 'Checkout process']
          }
        ]
      }),
      geminiModelUsed: 'gemini-pro',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  },
  sessions: {
    'session-1': {
      id: 'session-1',
      userId: 'user-123',
      questionnaireBlueprintId: 'questionnaire-1',
      platformUrl: 'https://example.com',
      status: 'COMPLETED',
      responses: {
        'q1': '4',
        'q2': 'Search'
      },
      humeSessionId: 'hume-123',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      sentimentReportId: 'report-1'
    }
  },
  reports: {
    'report-1': {
      id: 'report-1',
      userInteractionSessionId: 'session-1',
      reportData: {
        overallSentiment: 0.85,
        keyInsights: [
          'Users appreciate the search functionality',
          'Navigation could be improved',
          'Mobile experience is rated highly'
        ],
        emotionBreakdown: {
          joy: 0.7,
          anger: 0.05,
          sadness: 0.1,
          fear: 0.05,
          surprise: 0.05,
          disgust: 0.05
        },
        recommendations: [
          'Improve navigation menu organization',
          'Enhance product filtering options',
          'Add more detailed product descriptions'
        ],
        transcriptHighlights: [
          {
            text: 'I really like how fast the search returns results',
            sentiment: 0.9,
            emotion: 'joy'
          },
          {
            text: 'The menu structure is a bit confusing',
            sentiment: 0.3,
            emotion: 'frustration'
          }
        ],
        sentimentReport: '# Sentiment Analysis Report\n\n## Overall Sentiment: 85%\n\n...'
      },
      humeModelUsed: 'hume-v1',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  }
};

// Helper function to simulate API delay
const simulateDelay = (ms = 500) => new Promise(resolve => setTimeout(resolve, ms));

// Helper function to determine if we should use mock data
const useMockData = () => {
  return Platform.OS === 'web' && process.env.NODE_ENV === 'development';
};

// Jobs API
export const jobsApi = {
  // Get all jobs
  getJobs: async () => {
    if (useMockData()) {
      await simulateDelay();
      return MOCK_DATA.jobs;
    }

    const response = await fetch(`${API_BASE_URL}/api/jobs`);
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to fetch jobs');
    }
    return response.json();
  },

  // Get a specific job by ID
  getJob: async (id: string) => {
    if (useMockData()) {
      await simulateDelay();
      const job = MOCK_DATA.jobs.find(job => job.id === id);
      if (!job) throw new Error('Job not found');
      return job;
    }

    const response = await fetch(`${API_BASE_URL}/api/jobs/${id}`);
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to fetch job');
    }
    return response.json();
  },

  // Create a new job
  createJob: async (platformUrl: string, aiProvider: string = 'gemini') => {
    if (useMockData()) {
      await simulateDelay(1500);
      const newJob = {
        id: `job-${Date.now()}`,
        platformUrl,
        status: 'COMPLETED',
        aiProviderUsed: aiProvider,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        questionnaireBlueprintId: `questionnaire-${Date.now()}`,
        questionnaireBlueprint: {
          id: `questionnaire-${Date.now()}`,
          platformAnalysisJobId: `job-${Date.now()}`,
          questionnaireText: JSON.stringify({
            title: `${new URL(platformUrl).hostname} User Experience Survey`,
            description: `Help us improve ${new URL(platformUrl).hostname} by sharing your feedback`,
            questions: [
              {
                id: 'q1',
                text: 'How easy was it to navigate the website?',
                type: 'rating'
              },
              {
                id: 'q2',
                text: 'Which feature do you find most valuable?',
                type: 'multiple_choice',
                options: ['Search', 'Product listings', 'User reviews', 'Checkout process']
              },
              {
                id: 'q3',
                text: 'How would you rate the overall design?',
                type: 'rating'
              },
              {
                id: 'q4',
                text: 'What improvements would you suggest?',
                type: 'open_ended'
              }
            ]
          }),
          geminiModelUsed: aiProvider === 'gemini' ? 'gemini-pro' : 
                           aiProvider === 'openai' ? 'gpt-4o' : 
                           'llama3-8b-8192',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }
      };
      
      // Add to mock data
      MOCK_DATA.jobs.unshift(newJob);
      MOCK_DATA.questionnaires[newJob.questionnaireBlueprintId] = newJob.questionnaireBlueprint;
      
      return newJob;
    }

    const response = await fetch(`${API_BASE_URL}/api/jobs`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ platformUrl, aiProvider }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to create job');
    }
    return response.json();
  }
};

// Questionnaires API
export const questionnairesApi = {
  // Get a specific questionnaire by ID
  getQuestionnaire: async (id: string) => {
    if (useMockData()) {
      await simulateDelay();
      const questionnaire = MOCK_DATA.questionnaires[id];
      if (!questionnaire) throw new Error('Questionnaire not found');
      return questionnaire;
    }

    const response = await fetch(`${API_BASE_URL}/api/questionnaires/${id}`);
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to fetch questionnaire');
    }
    return response.json();
  }
};

// Sessions API
export const sessionsApi = {
  // Create a new session
  createSession: async (questionnaireId: string, userId: string) => {
    if (useMockData()) {
      await simulateDelay();
      const questionnaire = MOCK_DATA.questionnaires[questionnaireId];
      if (!questionnaire) throw new Error('Questionnaire not found');
      
      const job = MOCK_DATA.jobs.find(job => job.questionnaireBlueprintId === questionnaireId);
      if (!job) throw new Error('Associated job not found');
      
      const newSession = {
        id: `session-${Date.now()}`,
        userId,
        questionnaireBlueprintId: questionnaireId,
        platformUrl: job.platformUrl,
        status: 'PENDING',
        responses: {},
        humeSessionId: `hume-${Date.now()}`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      // Add to mock data
      MOCK_DATA.sessions[newSession.id] = newSession;
      
      return newSession;
    }

    const response = await fetch(`${API_BASE_URL}/api/sessions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ questionnaireId, userId }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to create session');
    }
    return response.json();
  },

  // Get a specific session by ID
  getSession: async (id: string) => {
    if (useMockData()) {
      await simulateDelay();
      const session = MOCK_DATA.sessions[id];
      if (!session) throw new Error('Session not found');
      return session;
    }

    const response = await fetch(`${API_BASE_URL}/api/sessions/${id}`);
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to fetch session');
    }
    return response.json();
  },

  // Update session responses
  updateSessionResponses: async (id: string, responses: Record<string, string>) => {
    if (useMockData()) {
      await simulateDelay();
      const session = MOCK_DATA.sessions[id];
      if (!session) throw new Error('Session not found');
      
      // Update session
      session.responses = { ...session.responses, ...responses };
      session.updatedAt = new Date().toISOString();
      
      return session;
    }

    const response = await fetch(`${API_BASE_URL}/api/sessions/${id}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ responses }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to update session responses');
    }
    return response.json();
  },

  // Complete a session
  completeSession: async (id: string) => {
    if (useMockData()) {
      await simulateDelay(2000);
      const session = MOCK_DATA.sessions[id];
      if (!session) throw new Error('Session not found');
      
      // Update session
      session.status = 'COMPLETED';
      session.updatedAt = new Date().toISOString();
      
      // Create a mock report
      const reportId = `report-${Date.now()}`;
      const newReport = {
        id: reportId,
        userInteractionSessionId: id,
        reportData: {
          overallSentiment: 0.75 + Math.random() * 0.2,
          keyInsights: [
            'User found the navigation intuitive',
            'Search functionality was highly rated',
            'Mobile experience could be improved'
          ],
          emotionBreakdown: {
            joy: 0.6 + Math.random() * 0.2,
            anger: Math.random() * 0.1,
            sadness: Math.random() * 0.1,
            fear: Math.random() * 0.05,
            surprise: 0.1 + Math.random() * 0.1,
            disgust: Math.random() * 0.05
          },
          recommendations: [
            'Enhance mobile responsiveness',
            'Add more filtering options to search',
            'Improve page load times'
          ],
          transcriptHighlights: [
            {
              text: 'I really like how easy it is to find products',
              sentiment: 0.9,
              emotion: 'joy'
            },
            {
              text: 'The checkout process is a bit confusing',
              sentiment: 0.4,
              emotion: 'frustration'
            },
            {
              text: 'Overall, I had a good experience',
              sentiment: 0.8,
              emotion: 'satisfaction'
            }
          ],
          sentimentReport: `# Sentiment Analysis Report\n\n## Overall Sentiment: ${Math.round((0.75 + Math.random() * 0.2) * 100)}%\n\n...`
        },
        humeModelUsed: 'hume-v1',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      // Add report to mock data and link to session
      MOCK_DATA.reports[reportId] = newReport;
      session.sentimentReportId = reportId;
      
      return session;
    }

    const response = await fetch(`${API_BASE_URL}/api/sessions/${id}/complete`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      }
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to complete session');
    }
    return response.json();
  }
};

// Reports API
export const reportsApi = {
  // Get a specific report by ID
  getReport: async (id: string) => {
    if (useMockData()) {
      await simulateDelay();
      const report = MOCK_DATA.reports[id];
      if (!report) throw new Error('Report not found');
      return report;
    }

    const response = await fetch(`${API_BASE_URL}/api/reports/${id}`);
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to fetch report');
    }
    return response.json();
  }
};