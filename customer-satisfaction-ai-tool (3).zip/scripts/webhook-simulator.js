/**
 * Webhook Simulator for Hume AI
 * 
 * This script simulates a webhook callback from Hume AI to test the webhook handler
 * without requiring an actual callback from Hume AI's servers.
 * 
 * Usage:
 *   node scripts/webhook-simulator.js
 */

const http = require('http');
const crypto = require('crypto');

// Configuration
const WEBHOOK_URL = 'http://localhost:8081/api/webhooks/hume';
const WEBHOOK_SECRET = process.env.HUME_WEBHOOK_SECRET || 'test_webhook_secret';

// Generate a sample webhook payload
const generateSamplePayload = () => {
  const sessionId = crypto.randomUUID();
  const reportId = crypto.randomUUID();
  
  return {
    id: crypto.randomUUID(),
    type: 'sentiment.analysis.completed',
    created_at: new Date().toISOString(),
    data: {
      session_id: sessionId,
      report_id: reportId,
      status: 'completed',
      results: {
        emotions: [
          { name: 'joy', score: 0.75 },
          { name: 'anger', score: 0.12 },
          { name: 'surprise', score: 0.45 },
          { name: 'fear', score: 0.08 },
          { name: 'sadness', score: 0.15 },
          { name: 'disgust', score: 0.05 },
          { name: 'confusion', score: 0.22 },
          { name: 'interest', score: 0.68 },
          { name: 'trust', score: 0.62 },
          { name: 'distress', score: 0.18 }
        ],
        sentiment: {
          positive: 0.65,
          negative: 0.15,
          neutral: 0.20
        },
        summary: "The user expressed generally positive sentiment about the platform, with high levels of joy, interest, and trust. There were some minor concerns indicated by low levels of anger and confusion. Overall, the emotional profile suggests a satisfied user with some specific areas for improvement.",
        recommendations: [
          "Focus on improving the areas that triggered confusion",
          "Maintain the features that generated joy and interest",
          "Address the minor concerns that led to anger"
        ]
      },
      metadata: {
        session_id: sessionId,
        user_id: "user_" + crypto.randomUUID().substring(0, 8),
        platform_url: "https://example.com/platform",
        questionnaire_id: "quest_" + crypto.randomUUID().substring(0, 8)
      }
    }
  };
};

// Generate a signature for the payload
const generateSignature = (payload, secret) => {
  const hmac = crypto.createHmac('sha256', secret);
  hmac.update(JSON.stringify(payload));
  return hmac.digest('hex');
};

// Send the webhook request
const sendWebhook = (url, payload, signature) => {
  const payloadString = JSON.stringify(payload);
  
  const options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(payloadString),
      'X-Hume-Signature': signature,
      'User-Agent': 'Hume-Webhook-Simulator/1.0'
    }
  };
  
  return new Promise((resolve, reject) => {
    const req = http.request(url, options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          body: data
        });
      });
    });
    
    req.on('error', (error) => {
      reject(error);
    });
    
    req.write(payloadString);
    req.end();
  });
};

// Main function
const main = async () => {
  try {
    console.log('🚀 Starting Hume AI Webhook Simulator');
    console.log(`📡 Target URL: ${WEBHOOK_URL}`);
    
    // Generate payload and signature
    const payload = generateSamplePayload();
    const signature = generateSignature(payload, WEBHOOK_SECRET);
    
    console.log('📦 Generated sample payload:');
    console.log(JSON.stringify(payload, null, 2));
    
    console.log('🔑 Generated signature:', signature);
    console.log('📤 Sending webhook request...');
    
    // Send the webhook request
    const response = await sendWebhook(WEBHOOK_URL, payload, signature);
    
    console.log(`📥 Response status: ${response.statusCode}`);
    console.log('📥 Response headers:', response.headers);
    console.log('📥 Response body:', response.body);
    
    if (response.statusCode >= 200 && response.statusCode < 300) {
      console.log('✅ Webhook simulation successful!');
    } else {
      console.log('❌ Webhook simulation failed!');
    }
  } catch (error) {
    console.error('❌ Error during webhook simulation:', error);
  }
};

// Run the main function
main();