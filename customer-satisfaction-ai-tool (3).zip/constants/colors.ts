const Colors = {
  primary: '#4361ee',
  primaryLight: '#4361ee20',
  secondary: '#3f37c9',
  background: '#ffffff',
  backgroundSecondary: '#f8f9fa',
  text: '#212529',
  textSecondary: '#495057',
  textTertiary: '#6c757d',
  border: '#dee2e6',
  error: '#dc3545',
  errorLight: '#f8d7da',
  errorText: '#721c24',
  warning: '#ffc107',
  warningLight: '#fff3cd',
  warningText: '#856404',
  success: '#28a745',
  successLight: '#d4edda',
  successText: '#155724',
  info: '#17a2b8',
  infoLight: '#d1ecf1',
  infoText: '#0c5460',
  disabled: '#e9ecef', // Added disabled color
};

export default Colors;