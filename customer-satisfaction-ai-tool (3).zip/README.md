# CSAT AI Tool

A customer satisfaction AI tool that uses multiple AI providers (Google Gemini, OpenAI, Groq) for questionnaire generation and Hume AI for sentiment analysis during user interviews.

## Features

- Platform analysis using multiple AI providers:
  - Google Gemini
  - OpenAI GPT-4o
  - Groq LLaMA 3
- Questionnaire generation based on platform analysis
- User interview session management
- Real-time sentiment analysis using Hume AI
- Comprehensive sentiment reports with actionable insights

## Getting Started

### Prerequisites

- Node.js 18 or higher
- Expo CLI (`npm install -g expo-cli`)
- Supabase account
- AI API keys:
  - Google Gemini API key
  - OpenAI API key
  - Groq API key
  - Hume AI API key

### Installation

1. Clone the repository
```bash
git clone https://github.com/your-username/csat-ai-tool.git
cd csat-ai-tool
```

2. Install dependencies
```bash
npm install
```

3. Set up environment variables
Create a `.env` file in the root directory with the following variables:
```
DATABASE_URL=your_supabase_postgres_connection_string
SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
GEMINI_API_KEY=your_gemini_api_key
OPENAI_API_KEY=your_openai_api_key
GROQ_API_KEY=your_groq_api_key
HUME_API_KEY=your_hume_api_key
HUME_WEBHOOK_SECRET=your_hume_webhook_secret
TESTING_MODE=true # Set to false in production
```

4. Initialize the database
```bash
npx prisma generate
npx prisma migrate dev
```

5. Start the development server
```bash
npx expo start
```

## Firebase Studio Setup

### Environment Variables in Firebase Studio

1. Open your project in Firebase Studio
2. Navigate to the Secret Manager in the Firebase Studio interface
3. Add each environment variable from your `.env.example` file:
   - DATABASE_URL
   - SUPABASE_URL
   - NEXT_PUBLIC_SUPABASE_URL
   - SUPABASE_SERVICE_ROLE_KEY
   - NEXT_PUBLIC_SUPABASE_ANON_KEY
   - GEMINI_API_KEY
   - OPENAI_API_KEY
   - GROQ_API_KEY
   - HUME_API_KEY
   - HUME_WEBHOOK_SECRET
   - TESTING_MODE (set to "false" for production)

### Running in Firebase Studio

1. Open a terminal in Firebase Studio
2. Install dependencies:
```bash
npm install
```

3. Generate Prisma client and run migrations:
```bash
npx prisma generate
npx prisma migrate dev
```

4. Start the Expo development server:
```bash
npx expo start --web
```

5. Access the preview by clicking on the web preview URL in the terminal or using the "Web Preview" button in the Firebase Studio interface.

### Testing Hume Webhooks in Firebase Studio

Since Firebase Studio doesn't expose local servers to the internet, you have three options for testing webhooks:

#### Option A: Simulated Webhook Testing

1. Create a test script to simulate Hume webhook callbacks:
```bash
node scripts/webhook-simulator.js
```

2. This script will send a simulated webhook payload to your local webhook endpoint.

#### Option B: Tunneling (if supported)

If Firebase Studio allows installing and running ngrok:

1. Install ngrok:
```bash
npm install -g ngrok
```

2. Expose your local server:
```bash
ngrok http 8081
```

3. Configure the generated ngrok URL in your Hume AI dashboard as the webhook URL.

#### Option C: Deploy for Testing

For full webhook testing, deploy your application to a public environment and configure the deployed webhook URL in Hume AI.

## Deployment

### Backend Deployment

The API routes and webhook handlers need to be deployed to a publicly accessible server. There are two recommended approaches:

#### Option A: Serverless Functions (Recommended)

1. Refactor API routes to serverless functions compatible with platforms like:
   - Vercel Serverless Functions
   - Google Cloud Functions
   - Supabase Edge Functions

2. Deploy the functions to your chosen platform
3. Update the Hume AI webhook configuration to point to your deployed webhook endpoint

#### Option B: Traditional Node.js Server

1. Extract API route logic into a standalone Node.js application using Express or Fastify
2. Containerize the application using Docker
3. Deploy to a platform like Google Cloud Run, Fly.io, or Render
4. Update the Hume AI webhook configuration to point to your deployed webhook endpoint

### Frontend Deployment with EAS

1. Configure EAS secrets for your production environment:
```bash
eas secret:create --scope project --name DATABASE_URL_PROD --value "your_prod_db_url" --type string
eas secret:create --scope project --name SUPABASE_URL_PROD --value "your_prod_supabase_url" --type string
eas secret:create --scope project --name NEXT_PUBLIC_SUPABASE_URL_PROD --value "your_prod_supabase_url" --type string
eas secret:create --scope project --name NEXT_PUBLIC_SUPABASE_ANON_KEY_PROD --value "your_prod_supabase_anon_key" --type string
eas secret:create --scope project --name GEMINI_API_KEY_PROD --value "your_prod_gemini_api_key" --type string
eas secret:create --scope project --name OPENAI_API_KEY_PROD --value "your_prod_openai_api_key" --type string
eas secret:create --scope project --name GROQ_API_KEY_PROD --value "your_prod_groq_api_key" --type string
eas secret:create --scope project --name HUME_API_KEY_PROD --value "your_prod_hume_api_key" --type string
eas secret:create --scope project --name HUME_WEBHOOK_SECRET_PROD --value "your_prod_hume_webhook_secret" --type string
eas secret:create --scope project --name API_BASE_URL_PROD --value "https://your-backend-url.com/api" --type string
```

2. Build for production:
```bash
eas build --profile production --platform all
```

3. Submit to app stores:
```bash
eas submit --platform ios
eas submit --platform android
```

4. Deploy updates:
```bash
eas update --branch production --message "Update description"
```

## AI Provider Configuration

### Google Gemini

1. Visit [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Create an API key
3. Add the key to your environment variables as `GEMINI_API_KEY`

### OpenAI

1. Visit [OpenAI Platform](https://platform.openai.com/api-keys)
2. Create an API key
3. Add the key to your environment variables as `OPENAI_API_KEY`

### Groq

1. Visit [Groq Cloud](https://console.groq.com/keys)
2. Create an API key
3. Add the key to your environment variables as `GROQ_API_KEY`

### Hume AI

1. Contact Hume AI for API access
2. Add the provided key to your environment variables as `HUME_API_KEY`
3. Configure webhook settings in the Hume AI dashboard to point to your deployed webhook endpoint

## License

This project is licensed under the MIT License - see the LICENSE file for details