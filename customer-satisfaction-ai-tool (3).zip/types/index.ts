export enum JobStatus {
  PENDING = 'PENDING',
  ANALYZING = 'ANALYZING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
}

export enum SessionStatus {
  PENDING = 'PENDING',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
}

export interface PlatformAnalysisJob {
  id: string;
  platformUrl: string;
  status: JobStatus;
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
  questionnaireBlueprintId?: string;
  errorMessage?: string;
  questionnaireBlueprint?: QuestionnaireBlueprint;
}

export interface Question {
  id: string;
  text: string;
  type: string;
  options?: string[];
}

export interface QuestionnaireBlueprint {
  id: string;
  platformAnalysisJobId: string;
  questionnaireText: string;
  createdAt: string;
  updatedAt: string;
  platformAnalysisJob?: PlatformAnalysisJob;
  title?: string;
  description?: string;
  questions?: Question[];
  geminiModelUsed?: string;
}

export interface SessionResponse {
  id: string;
  sessionId: string;
  questionId: string;
  answer: string;
  createdAt: string;
}

export interface UserInteractionSession {
  id: string;
  questionnaireId: string;
  userId: string;
  platformUrl: string;
  status: SessionStatus;
  startedAt?: string;
  completedAt?: string;
  createdAt: string;
  updatedAt: string;
  responses?: SessionResponse[];
  sentimentReportId?: string;
  errorMessage?: string;
  questionnaireBlueprint?: QuestionnaireBlueprint;
  sentimentReport?: SentimentReport;
  humeSessionId?: string;
}

export interface SentimentReport {
  id: string;
  sessionId: string;
  overallSentiment: number;
  keyInsights: string[];
  reportData: {
    sentimentReport: string;
    [key: string]: any;
  };
  createdAt: string;
  updatedAt: string;
  userInteractionSessionId?: string;
  userInteractionSession?: UserInteractionSession;
  humeModelUsed?: string;
}

export interface Settings {
  apiKey: string;
  darkMode: boolean;
  defaultUserId: string;
}