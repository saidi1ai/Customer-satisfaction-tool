import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { UserInteractionSession, SessionStatus, SentimentReport } from '@/types';
import { generateSentimentReport } from '@/services/aiService';

/**
 * SessionStore manages the state for user interaction sessions and sentiment reports.
 * It handles creating, retrieving, updating, and deleting sessions and reports,
 * as well as managing loading states and errors.
 */
interface SessionState {
  sessions: UserInteractionSession[];
  reports: SentimentReport[];
  isLoading: boolean;
  error: string | null;
  
  // Actions
  createSession: (userId: string, questionnaireBlueprintId: string, platformUrl: string) => Promise<UserInteractionSession>;
  getSessions: () => UserInteractionSession[];
  getSessionById: (id: string) => UserInteractionSession | undefined;
  getReportById: (id: string) => SentimentReport | undefined;
  getReportBySessionId: (sessionId: string) => SentimentReport | undefined;
  updateSessionStatus: (id: string, status: SessionStatus, errorMessage?: string) => void;
  saveSessionResponses: (id: string, responses: Record<string, string>) => void;
  generateReport: (sessionId: string, questionnaireText: string, responses: Record<string, string>) => Promise<SentimentReport | null>;
  retryReport: (sessionId: string, questionnaireText: string, responses: Record<string, string>) => Promise<SentimentReport | null>;
  deleteSession: (sessionId: string) => void;
  clearError: () => void;
  clearAllData: () => void;
}

export const useSessionStore = create<SessionState>()(
  persist(
    (set, get) => ({
      sessions: [],
      reports: [],
      isLoading: false,
      error: null,
      
      /**
       * Creates a new user interaction session
       * @param userId The ID of the user
       * @param questionnaireBlueprintId The ID of the questionnaire blueprint
       * @param platformUrl The URL of the platform
       * @returns A promise that resolves to the created session
       */
      createSession: async (userId: string, questionnaireBlueprintId: string, platformUrl: string) => {
        set({ isLoading: true, error: null });
        
        try {
          // Generate a unique ID for the session
          const sessionId = `session-${Date.now()}`;
          
          // Create a new session
          const newSession: UserInteractionSession = {
            id: sessionId,
            userId,
            platformUrl,
            questionnaireBlueprintId,
            status: SessionStatus.PENDING,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            responses: {},
          };
          
          // Add the session to the store
          set(state => ({
            sessions: [newSession, ...state.sessions],
            isLoading: false
          }));
          
          return newSession;
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
          
          set({ 
            isLoading: false, 
            error: errorMessage
          });
          
          throw error;
        }
      },
      
      /**
       * Gets all sessions
       * @returns An array of all sessions
       */
      getSessions: () => {
        return get().sessions;
      },
      
      /**
       * Gets a session by ID
       * @param id The ID of the session to get
       * @returns The session with the specified ID, or undefined if not found
       */
      getSessionById: (id: string) => {
        return get().sessions.find(session => session.id === id);
      },
      
      /**
       * Gets a report by ID
       * @param id The ID of the report to get
       * @returns The report with the specified ID, or undefined if not found
       */
      getReportById: (id: string) => {
        return get().reports.find(report => report.id === id);
      },
      
      /**
       * Gets a report by session ID
       * @param sessionId The ID of the session to get the report for
       * @returns The report for the specified session, or undefined if not found
       */
      getReportBySessionId: (sessionId: string) => {
        const session = get().sessions.find(s => s.id === sessionId);
        if (session?.sentimentReportId) {
          return get().reports.find(r => r.id === session.sentimentReportId);
        }
        return undefined;
      },
      
      /**
       * Updates the status of a session
       * @param id The ID of the session to update
       * @param status The new status
       * @param errorMessage Optional error message
       */
      updateSessionStatus: (id: string, status: SessionStatus, errorMessage?: string) => {
        set(state => ({
          sessions: state.sessions.map(session => {
            if (session.id === id) {
              return {
                ...session,
                status,
                errorMessage: errorMessage || session.errorMessage,
                updatedAt: new Date().toISOString(),
              };
            }
            return session;
          })
        }));
      },
      
      /**
       * Saves responses for a session
       * @param id The ID of the session to save responses for
       * @param responses The responses to save
       */
      saveSessionResponses: (id: string, responses: Record<string, string>) => {
        set(state => ({
          sessions: state.sessions.map(session => {
            if (session.id === id) {
              return {
                ...session,
                responses,
                updatedAt: new Date().toISOString(),
              };
            }
            return session;
          })
        }));
      },
      
      /**
       * Generates a sentiment report for a session
       * @param sessionId The ID of the session to generate a report for
       * @param questionnaireText The text of the questionnaire
       * @param responses The user's responses to the questionnaire
       * @returns A promise that resolves to the generated report or null if an error occurred
       */
      generateReport: async (sessionId: string, questionnaireText: string, responses: Record<string, string>) => {
        set({ isLoading: true, error: null });
        
        try {
          // Update session status to in progress
          get().updateSessionStatus(sessionId, SessionStatus.IN_PROGRESS);
          
          // Generate sentiment report
          const result = await generateSentimentReport(questionnaireText, responses);
          
          if (result.success && result.data) {
            // Generate a unique ID for the report
            const reportId = `report-${Date.now()}`;
            
            // Create a new report
            const newReport: SentimentReport = {
              id: reportId,
              userInteractionSessionId: sessionId,
              reportData: result.data,
              humeModelUsed: "hume-1.0",
              createdAt: new Date().toISOString(),
            };
            
            // Update the session with the report ID and completed status
            set(state => ({
              sessions: state.sessions.map(session => {
                if (session.id === sessionId) {
                  return {
                    ...session,
                    sentimentReportId: reportId,
                    status: SessionStatus.COMPLETED,
                    updatedAt: new Date().toISOString(),
                  };
                }
                return session;
              }),
              reports: [newReport, ...state.reports],
              isLoading: false
            }));
            
            return newReport;
          } else {
            // Update session with failed status and error message
            get().updateSessionStatus(
              sessionId, 
              SessionStatus.FAILED, 
              result.error || "Failed to generate sentiment report"
            );
            
            set({ 
              isLoading: false, 
              error: result.error || "Failed to generate sentiment report" 
            });
            
            return null;
          }
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
          
          // Update session with failed status and error message
          get().updateSessionStatus(sessionId, SessionStatus.FAILED, errorMessage);
          
          set({ 
            isLoading: false, 
            error: errorMessage
          });
          
          return null;
        }
      },
      
      /**
       * Retries generating a sentiment report for a session
       * @param sessionId The ID of the session to retry generating a report for
       * @param questionnaireText The text of the questionnaire
       * @param responses The user's responses to the questionnaire
       * @returns A promise that resolves to the generated report or null if an error occurred
       */
      retryReport: async (sessionId: string, questionnaireText: string, responses: Record<string, string>) => {
        // Similar to generateReport but specifically for retrying failed reports
        set({ isLoading: true, error: null });
        
        try {
          // Update session status to in progress
          get().updateSessionStatus(sessionId, SessionStatus.IN_PROGRESS);
          
          // Generate sentiment report
          const result = await generateSentimentReport(questionnaireText, responses);
          
          if (result.success && result.data) {
            // Generate a unique ID for the report
            const reportId = `report-${Date.now()}`;
            
            // Create a new report
            const newReport: SentimentReport = {
              id: reportId,
              userInteractionSessionId: sessionId,
              reportData: result.data,
              humeModelUsed: "hume-1.0",
              createdAt: new Date().toISOString(),
            };
            
            // If there's an existing report, remove it
            const session = get().getSessionById(sessionId);
            if (session?.sentimentReportId) {
              set(state => ({
                reports: state.reports.filter(r => r.id !== session.sentimentReportId)
              }));
            }
            
            // Update the session with the new report ID and completed status
            set(state => ({
              sessions: state.sessions.map(session => {
                if (session.id === sessionId) {
                  return {
                    ...session,
                    sentimentReportId: reportId,
                    status: SessionStatus.COMPLETED,
                    errorMessage: undefined,
                    updatedAt: new Date().toISOString(),
                  };
                }
                return session;
              }),
              reports: [newReport, ...state.reports],
              isLoading: false
            }));
            
            return newReport;
          } else {
            // Update session with failed status and error message
            get().updateSessionStatus(
              sessionId, 
              SessionStatus.FAILED, 
              result.error || "Failed to generate sentiment report"
            );
            
            set({ 
              isLoading: false, 
              error: result.error || "Failed to generate sentiment report" 
            });
            
            return null;
          }
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
          
          // Update session with failed status and error message
          get().updateSessionStatus(sessionId, SessionStatus.FAILED, errorMessage);
          
          set({ 
            isLoading: false, 
            error: errorMessage
          });
          
          return null;
        }
      },
      
      /**
       * Deletes a session and its associated report
       * @param sessionId The ID of the session to delete
       */
      deleteSession: (sessionId: string) => {
        const session = get().getSessionById(sessionId);
        if (!session) return;
        
        // If session has a report, also remove it
        if (session.sentimentReportId) {
          set(state => ({
            reports: state.reports.filter(r => r.id !== session.sentimentReportId)
          }));
        }
        
        // Remove the session
        set(state => ({
          sessions: state.sessions.filter(s => s.id !== sessionId)
        }));
      },
      
      /**
       * Clears the current error
       */
      clearError: () => {
        set({ error: null });
      },
      
      /**
       * Clears all sessions and reports
       */
      clearAllData: () => {
        set({ sessions: [], reports: [], error: null, isLoading: false });
      }
    }),
    {
      name: 'csat-session-storage',
      storage: createJSONStorage(() => AsyncStorage),
      onRehydrateStorage: () => {
        // Handle potential storage errors
        return (state, error) => {
          if (error) {
            console.error('Error rehydrating session store:', error);
          }
        };
      },
    }
  )
);