import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { APP_NAME, DEFAULT_SETTINGS } from '@/app/config';

interface SettingsState {
  apiKey: string;
  darkMode: boolean;
  defaultUserId: string;
  defaultAiProvider: string;
  updateApiKey: (key: string) => void;
  toggleDarkMode: () => void;
  updateDefaultUserId: (id: string) => void;
  updateDefaultAiProvider: (provider: string) => void;
}

// Create the store with persistence
export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      apiKey: '',
      darkMode: false,
      defaultUserId: `user-${Math.floor(Math.random() * 10000)}`,
      defaultAiProvider: DEFAULT_SETTINGS.aiProvider,
      updateApiKey: (key: string) => set({ apiKey: key }),
      toggleDarkMode: () => set((state) => ({ darkMode: !state.darkMode })),
      updateDefaultUserId: (id: string) => set({ defaultUserId: id }),
      updateDefaultAiProvider: (provider: string) => set({ defaultAiProvider: provider }),
    }),
    {
      name: `${APP_NAME.toLowerCase().replace(/\s+/g, '-')}-settings`,
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);