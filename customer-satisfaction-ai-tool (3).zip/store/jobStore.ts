import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { PlatformAnalysisJob, JobStatus, QuestionnaireBlueprint, ApiResponse } from '@/types';
import { generateQuestionnaire } from '@/services/aiService';

/**
 * JobStore manages the state for platform analysis jobs and questionnaire blueprints.
 * It handles creating, retrieving, updating, and deleting jobs and questionnaires,
 * as well as managing loading states and errors.
 */
interface JobState {
  jobs: PlatformAnalysisJob[];
  questionnaires: QuestionnaireBlueprint[];
  isLoading: boolean;
  error: string | null;
  
  // Actions
  createJob: (platformUrl: string) => Promise<PlatformAnalysisJob | null>;
  getJobs: () => PlatformAnalysisJob[];
  getJobById: (id: string) => PlatformAnalysisJob | undefined;
  getQuestionnaireById: (id: string) => QuestionnaireBlueprint | undefined;
  getQuestionnaireByJobId: (jobId: string) => QuestionnaireBlueprint | undefined;
  retryJob: (jobId: string) => Promise<PlatformAnalysisJob | null>;
  deleteJob: (jobId: string) => void;
  clearError: () => void;
  clearAllData: () => void;
}

export const useJobStore = create<JobState>()(
  persist(
    (set, get) => ({
      jobs: [],
      questionnaires: [],
      isLoading: false,
      error: null,
      
      /**
       * Creates a new platform analysis job and generates a questionnaire
       * @param platformUrl The URL of the platform to analyze
       * @returns A promise that resolves to the created job or null if an error occurred
       */
      createJob: async (platformUrl: string) => {
        set({ isLoading: true, error: null });
        
        try {
          // Generate a unique ID for the job
          const jobId = Date.now().toString();
          
          // Create a new job
          const newJob: PlatformAnalysisJob = {
            id: jobId,
            platformUrl,
            status: JobStatus.ANALYZING,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
          
          // Add the job to the store
          set(state => ({
            jobs: [newJob, ...state.jobs]
          }));
          
          // Generate the questionnaire using AI
          const result = await generateQuestionnaire(platformUrl);
          
          if (result.success && result.data) {
            // Create the questionnaire blueprint
            const questionnaireId = `q-${Date.now()}`;
            const newQuestionnaire: QuestionnaireBlueprint = {
              id: questionnaireId,
              platformAnalysisJobId: jobId,
              questionnaireText: result.data,
              geminiModelUsed: "gemini-1.0",
              createdAt: new Date().toISOString(),
            };
            
            // Update the job with the questionnaire ID and completed status
            const updatedJob: PlatformAnalysisJob = {
              ...newJob,
              questionnaireBlueprintId: questionnaireId,
              status: JobStatus.COMPLETED,
              updatedAt: new Date().toISOString(),
            };
            
            // Update the store
            set(state => ({
              jobs: state.jobs.map(job => job.id === jobId ? updatedJob : job),
              questionnaires: [newQuestionnaire, ...state.questionnaires],
              isLoading: false
            }));
            
            return updatedJob;
          } else {
            // Update the job with failed status and error message
            const updatedJob: PlatformAnalysisJob = {
              ...newJob,
              status: JobStatus.FAILED,
              errorMessage: result.error || "Failed to generate questionnaire",
              updatedAt: new Date().toISOString(),
            };
            
            // Update the store
            set(state => ({
              jobs: state.jobs.map(job => job.id === jobId ? updatedJob : job),
              isLoading: false,
              error: result.error || "Failed to generate questionnaire"
            }));
            
            return null;
          }
        } catch (error) {
          // Handle unexpected errors
          const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
          
          set({ 
            isLoading: false, 
            error: errorMessage
          });
          
          return null;
        }
      },
      
      /**
       * Retries a failed job by generating a new questionnaire
       * @param jobId The ID of the job to retry
       * @returns A promise that resolves to the updated job or null if an error occurred
       */
      retryJob: async (jobId: string) => {
        const job = get().getJobById(jobId);
        
        if (!job) {
          set({ error: "Job not found" });
          return null;
        }
        
        // Update job status to analyzing
        set(state => ({
          jobs: state.jobs.map(j => 
            j.id === jobId 
              ? { ...j, status: JobStatus.ANALYZING, updatedAt: new Date().toISOString(), errorMessage: undefined } 
              : j
          ),
          isLoading: true,
          error: null
        }));
        
        try {
          // Generate the questionnaire using AI
          const result = await generateQuestionnaire(job.platformUrl);
          
          if (result.success && result.data) {
            // Create the questionnaire blueprint
            const questionnaireId = `q-${Date.now()}`;
            const newQuestionnaire: QuestionnaireBlueprint = {
              id: questionnaireId,
              platformAnalysisJobId: jobId,
              questionnaireText: result.data,
              geminiModelUsed: "gemini-1.0",
              createdAt: new Date().toISOString(),
            };
            
            // Update the job with the questionnaire ID and completed status
            const updatedJob: PlatformAnalysisJob = {
              ...job,
              questionnaireBlueprintId: questionnaireId,
              status: JobStatus.COMPLETED,
              errorMessage: undefined,
              updatedAt: new Date().toISOString(),
            };
            
            // Update the store
            set(state => ({
              jobs: state.jobs.map(j => j.id === jobId ? updatedJob : j),
              questionnaires: [newQuestionnaire, ...state.questionnaires],
              isLoading: false
            }));
            
            return updatedJob;
          } else {
            // Update the job with failed status and error message
            const updatedJob: PlatformAnalysisJob = {
              ...job,
              status: JobStatus.FAILED,
              errorMessage: result.error || "Failed to generate questionnaire",
              updatedAt: new Date().toISOString(),
            };
            
            // Update the store
            set(state => ({
              jobs: state.jobs.map(j => j.id === jobId ? updatedJob : j),
              isLoading: false,
              error: result.error || "Failed to generate questionnaire"
            }));
            
            return null;
          }
        } catch (error) {
          // Handle unexpected errors
          const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
          
          // Update the job with failed status and error message
          set(state => ({
            jobs: state.jobs.map(j => 
              j.id === jobId 
                ? { ...j, status: JobStatus.FAILED, errorMessage, updatedAt: new Date().toISOString() } 
                : j
            ),
            isLoading: false,
            error: errorMessage
          }));
          
          return null;
        }
      },
      
      /**
       * Gets all jobs
       * @returns An array of all jobs
       */
      getJobs: () => {
        return get().jobs;
      },
      
      /**
       * Gets a job by ID
       * @param id The ID of the job to get
       * @returns The job with the specified ID, or undefined if not found
       */
      getJobById: (id: string) => {
        return get().jobs.find(job => job.id === id);
      },
      
      /**
       * Gets a questionnaire by ID
       * @param id The ID of the questionnaire to get
       * @returns The questionnaire with the specified ID, or undefined if not found
       */
      getQuestionnaireById: (id: string) => {
        return get().questionnaires.find(q => q.id === id);
      },
      
      /**
       * Gets a questionnaire by job ID
       * @param jobId The ID of the job to get the questionnaire for
       * @returns The questionnaire for the specified job, or undefined if not found
       */
      getQuestionnaireByJobId: (jobId: string) => {
        const job = get().jobs.find(j => j.id === jobId);
        if (job?.questionnaireBlueprintId) {
          return get().questionnaires.find(q => q.id === job.questionnaireBlueprintId);
        }
        return undefined;
      },
      
      /**
       * Deletes a job and its associated questionnaire
       * @param jobId The ID of the job to delete
       */
      deleteJob: (jobId: string) => {
        const job = get().getJobById(jobId);
        if (!job) return;
        
        // If job has a questionnaire, also remove it
        if (job.questionnaireBlueprintId) {
          set(state => ({
            questionnaires: state.questionnaires.filter(q => q.id !== job.questionnaireBlueprintId)
          }));
        }
        
        // Remove the job
        set(state => ({
          jobs: state.jobs.filter(j => j.id !== jobId)
        }));
      },
      
      /**
       * Clears the current error
       */
      clearError: () => {
        set({ error: null });
      },
      
      /**
       * Clears all jobs and questionnaires
       */
      clearAllData: () => {
        set({ jobs: [], questionnaires: [], error: null, isLoading: false });
      }
    }),
    {
      name: 'csat-job-storage',
      storage: createJSONStorage(() => AsyncStorage),
      onRehydrateStorage: () => {
        // Handle potential storage errors
        return (state, error) => {
          if (error) {
            console.error('Error rehydrating job store:', error);
          }
        };
      },
    }
  )
);