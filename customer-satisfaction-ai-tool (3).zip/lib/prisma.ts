// This is your Prisma client singleton
let prisma: any;

try {
  // Use dynamic import to avoid TypeScript errors
  const { PrismaClient } = require('@prisma/client');
  
  // PrismaClient is attached to the `global` object in development to prevent
  // exhausting your database connection limit.
  const globalForPrisma = global as unknown as { prisma: any };

  prisma = globalForPrisma.prisma || new PrismaClient({
    log: ['query', 'error', 'warn'],
  });

  if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma;
} catch (error) {
  console.error('Failed to initialize Prisma client:', error);
  // Provide a mock implementation for development if Prisma is not available
  prisma = {
    platformAnalysisJob: createMockModel('platformAnalysisJob'),
    questionnaireBlueprint: createMockModel('questionnaireBlueprint'),
    userInteractionSession: createMockModel('userInteractionSession'),
    sentimentReport: createMockModel('sentimentReport'),
  };
}

// Helper function to create mock models for development
function createMockModel(modelName: string) {
  return {
    findUnique: async () => {
      console.log(`Mock ${modelName}.findUnique called`);
      return null;
    },
    findMany: async () => {
      console.log(`Mock ${modelName}.findMany called`);
      return [];
    },
    create: async (data: any) => {
      console.log(`Mock ${modelName}.create called with:`, data);
      return { id: 'mock-id', ...data.data };
    },
    update: async (data: any) => {
      console.log(`Mock ${modelName}.update called with:`, data);
      return { id: data.where.id, ...data.data };
    },
    delete: async (data: any) => {
      console.log(`Mock ${modelName}.delete called with:`, data);
      return { id: data.where.id };
    },
  };
}

export default prisma;