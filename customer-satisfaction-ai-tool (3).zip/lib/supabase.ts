import AsyncStorage from '@react-native-async-storage/async-storage';
import { SUPABASE_URL, SUPABASE_ANON_KEY } from '@/app/config';

// Create a mock Supabase client if credentials are not available
const createMockClient = () => {
  console.warn('Using mock Supabase client. Real-time updates will not work.');
  
  return {
    from: (table: string) => ({
      select: (columns: string = '*') => ({
        eq: (column: string, value: any) => ({
          single: () => Promise.resolve({ data: null, error: { message: 'Mock database error' } }),
          order: () => ({
            limit: () => Promise.resolve({ data: [], error: null })
          })
        }),
        order: () => ({
          limit: () => Promise.resolve({ data: [], error: null })
        })
      }),
      insert: (data: any) => Promise.resolve({ data: null, error: null }),
      update: (data: any) => ({
        eq: (column: string, value: any) => Promise.resolve({ data: null, error: null })
      }),
      delete: () => ({
        eq: (column: string, value: any) => Promise.resolve({ data: null, error: null })
      })
    }),
    channel: (name: string) => ({
      on: (event: string, filter: any, callback: (payload: any) => void) => ({
        subscribe: () => {
          console.log(`Mock subscription to channel: ${name}`);
          return { data: { subscription: { unsubscribe: () => {} } } };
        },
      }),
    }),
    removeChannel: (channel: any) => {
      console.log('Mock removeChannel called');
      return Promise.resolve();
    },
    auth: {
      signUp: () => Promise.resolve({ data: null, error: null }),
      signIn: () => Promise.resolve({ data: null, error: null }),
      signOut: () => Promise.resolve({ error: null }),
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } })
    }
  };
};

// Create a Supabase client
const supabase = createMockClient();

export default supabase;